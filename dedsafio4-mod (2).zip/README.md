# DEDsafío 4 – Mod para Minecraft Forge 1.20.1 (Java 17)

Mecánicas inspiradas en DEDsafío Minecraft 4. Mod id: `dedsafio4`.

| Mecánica | Qué hace |
|---|---|
| **Campo de fuerza de Revil** | Esfera geodésica de hexágonos translucidos con bordes luminosos (como la cúpula de la referencia). Envuelve una zona o sigue a una entidad, bloquea ataques / proyectiles / explosiones / mobs y tiene tamaño, resistencia y duración configurables. **Los jugadores abren una puertita cuadrada** al acercarse a la pared para salir (o entrar); se cierra sola. |
| **Espacio mental de Eón** | Transición con **shader GLSL real**: vacío negro con destellos blancos que salen del centro hacia los bordes. Al terminar, teletransporta al jugador a la dimensión astral oscura `dedsafio4:mind_space` (isla de obsidiana, cristales, islas flotantes). Volver = repetir el viaje. |
| **Diálogos de Eón** | Lo que escribes en el chat aparece como una nube de diálogo sobre tu cabeza (visible para los jugadores que te ven). |

## 1. Compilar en GitHub Codespaces

```bash
# dentro de tu repositorio (raiz), con dedsafio4-mod.zip subido al repo:
unzip -o dedsafio4-mod.zip

# Java 17
sudo apt-get update -y && sudo apt-get install -y openjdk-17-jdk unzip
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
java -version            # debe decir 17

# compilar
chmod +x gradlew
./gradlew build
ls build/libs/           # -> dedsafio4-1.0.0.jar
```
(Atajo: `bash scripts/codespaces-setup.sh` hace todo lo anterior.)
La primera compilación descarga Forge/Minecraft y tarda varios minutos. Para probar sin instalar: `./gradlew runClient` (necesita entorno gráfico) o `./gradlew runServer`.

Instalación: copia `build/libs/dedsafio4-1.0.0.jar` a `mods/` de **Forge 1.20.1 (47.x)**, en servidor **y** clientes (el mod necesita estar en ambos).

## 2. Items (pestaña creativa «DEDsafío 4»)
* **Núcleo de Revil** – clic derecho: crea un campo a tus pies. Shift + clic derecho: quita tu campo más cercano.
* **Orbe astral de Eón** – clic derecho: viaje al Espacio mental (o de vuelta).
* **Tecla J**: panel visual del staff (botones que ejecutan los comandos).

## 3. Comandos (`/dedsafio …`, requieren permiso 2 = staff)
`<id>` puede ser un número o `nearest` (el campo más cercano).

### Campo de fuerza
| Comando | Efecto |
|---|---|
| `forcefield enable` / `disable` | Activa / desactiva la mecánica completa |
| `forcefield create [radio [resistencia [segundos]]]` | Crea un campo en tu posición |
| `forcefield create_at <x y z> [radio [resistencia [segundos]]]` | Crea un campo en unas coordenadas |
| `forcefield attach <entidad> [radio [resistencia [segundos]]]` | Campo que sigue a una entidad |
| `forcefield remove <id\|nearest\|all>` | Elimina campos |
| `forcefield list` / `info <id>` / `heal <id>` | Consulta / restaura resistencia |
| `forcefield set <id> <propiedad> <valor>` | Cambia un campo existente |
| `forcefield member <id> add\|remove <jugador>` | Miembros (para `access MEMBERS`) |
| `forcefield defaults` / `defaults <propiedad> <valor>` | Valores por defecto de los campos nuevos |

Propiedades (`set` y `defaults`):
`radius` · `resistance` · `seconds` (0 = infinito) · `regen` (resistencia/seg) · `color` / `color2` (`#RRGGBB`) · `opacity` (0.02-1) · `edge` (grosor de bordes) · `pulse` (intensidad del brillo animado) · `doorsize` (lado de la puertita en bloques) · `doortime` (ticks abierta) · `access` (`ALL`, `MEMBERS`, `OPS`, `NONE` = quién puede abrir la puertita) · `mobs` · `projectiles` · `explosions` · `attacks` (`true/false`: qué protege).
Solo en `defaults`: `damage` (multiplicador de daño al campo), `projectilecost`, `explosioncost`, `maxfields` (por jugador), `opendistance` (distancia a la pared a la que se abre la puerta).

### Espacio mental
| Comando | Efecto |
|---|---|
| `void enable` / `disable` | Activa / desactiva |
| `void travel [jugadores]` | Inicia el viaje (ida o vuelta) |
| `void set <duration\|intensity\|color\|cooldown\|height> <valor>` | `duration` en segundos (2-30), `intensity` (0.2-5, velocidad de los destellos), `color` del destello, `cooldown` en s, `height` (Y de la plataforma) |
| `void rebuild` / `void info` | Reconstruye la plataforma / muestra la config |

### Diálogos
| Comando | Efecto |
|---|---|
| `dialogue enable` / `disable` | Activa / desactiva |
| `dialogue mode all\|list` | Todos los jugadores o solo la lista |
| `dialogue add\|remove <jugador>` | Gestiona la lista (modo `list`) |
| `dialogue say <jugador> <texto>` | Fuerza una nube |
| `dialogue set <duration\|scale\|width\|height\|color\|textcolor> <valor>` | Segundos, escala, ancho máx., altura, color de nube y de texto |

### Permisos
`permissions <forcefield|void|dialogue> level <0-4>` – nivel mínimo para usar los items/diálogos (por defecto 2, 2 y 0).
`permissions <mecánica> allow|revoke <jugador>` – excepciones individuales.
`status` – resumen general.

Ejemplos:
```
/dedsafio forcefield create 20 500 300
/dedsafio forcefield set nearest color #00E5FF
/dedsafio forcefield set nearest access MEMBERS
/dedsafio forcefield attach Revil 8 300 0
/dedsafio void set duration 8
/dedsafio void set color #CFA8FF
/dedsafio dialogue mode list
/dedsafio permissions void level 0
```

## 4. Cómo funciona (cliente/servidor)
* El servidor es la autoridad: física de la pared, puertitas, daño, viaje y teletransporte.
* Paquetes (`SimpleChannel`): `FieldSyncPacket` (campos y puertas), `HitPacket` (ondulación/sonido/rotura), `DialoguePacket`, `WarpPacket`.
* La puerta usa la misma matemática (`DoorMath`) en servidor (lo que puedes atravesar) y cliente (lo que se recorta de la cúpula).
* Datos persistentes en el mundo (`SavedData`): ajustes, campos y puntos de retorno.

## 5. Estructura de assets
`src/main/resources/assets/dedsafio4`: texturas (items, partículas, GUI), modelos, `sounds.json` + `.ogg`, `particles/spark.json`, shader `shaders/core/warp_vortex.*`, idiomas es/en. `data/dedsafio4`: dimensión `mind_space`. `tools/generate_assets.py` regenera texturas y sonidos.
