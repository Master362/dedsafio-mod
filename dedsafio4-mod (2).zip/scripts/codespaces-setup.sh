#!/usr/bin/env bash
# Instala Java 17 en GitHub Codespaces (Ubuntu/Debian) y compila el mod.
set -euo pipefail
sudo apt-get update -y
sudo apt-get install -y openjdk-17-jdk unzip
export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
export PATH="$JAVA_HOME/bin:$PATH"
sudo update-alternatives --set java "$JAVA_HOME/bin/java" || true
sudo update-alternatives --set javac "$JAVA_HOME/bin/javac" || true
java -version
chmod +x gradlew
./gradlew build --no-daemon
echo "Listo: $(ls build/libs/*.jar)"
