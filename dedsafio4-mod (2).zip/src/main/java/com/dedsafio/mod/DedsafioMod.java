package com.dedsafio.mod;

import com.dedsafio.mod.net.ModNetwork;
import com.dedsafio.mod.registry.ModItems;
import com.dedsafio.mod.registry.ModParticles;
import com.dedsafio.mod.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DedsafioMod.MODID)
public class DedsafioMod {
    public static final String MODID = "dedsafio4";

    public DedsafioMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModParticles.PARTICLES.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
