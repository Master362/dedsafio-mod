package com.dedsafio.mod.client;

import com.dedsafio.mod.net.FieldSyncPacket;
import com.dedsafio.mod.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Copia en el cliente de los campos de fuerza de la dimension actual (la envia el servidor). */
public final class ClientFields {
    public static final Map<Integer, ClientField> FIELDS = new HashMap<>();

    public static final class ClientDoor {
        public double dx, dy, dz;
        public long open, expire;
    }

    public static final class ClientField {
        public int id;
        public double x, y, z;
        public float radius, resistance, maxResistance;
        /** Tick de cliente en el que termina (-1 = infinito). */
        public long end;
        public int color1, color2;
        public float opacity, edge, pulse, doorSize;
        public int followId;
        public final List<ClientDoor> doors = new ArrayList<>();
        public float spawnTime;
        public float hitTime = -1000.0f;
        public float hx, hy = 1.0f, hz, hitStrength;

        /** Centro interpolado (si sigue a una entidad usa su posicion visual). */
        public Vec3 center(ClientLevel level, float pt) {
            if (followId >= 0) {
                Entity e = level.getEntity(followId);
                if (e != null) {
                    return e.getPosition(pt).add(0.0, e.getBbHeight() / 2.0, 0.0);
                }
            }
            return new Vec3(x, y, z);
        }
    }

    private ClientFields() {}

    public static void clear() {
        FIELDS.clear();
    }

    public static void apply(FieldSyncPacket p) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || !level.dimension().location().equals(p.dimension)) {
            return;
        }
        long offset = p.serverTime - level.getGameTime();
        float now = level.getGameTime();
        Map<Integer, ClientField> next = new HashMap<>();
        for (FieldSyncPacket.Entry e : p.entries) {
            ClientField old = FIELDS.get(e.id);
            ClientField f = old != null ? old : new ClientField();
            if (old == null) {
                f.spawnTime = now;
            }
            f.id = e.id;
            f.x = e.x; f.y = e.y; f.z = e.z;
            f.radius = e.radius; f.resistance = e.resistance; f.maxResistance = e.maxResistance;
            f.end = e.endTick < 0 ? -1L : e.endTick - offset;
            f.color1 = e.color1; f.color2 = e.color2;
            f.opacity = e.opacity; f.edge = e.edge; f.pulse = e.pulse; f.doorSize = e.doorSize;
            f.followId = e.followId;
            List<ClientDoor> oldDoors = new ArrayList<>(f.doors);
            f.doors.clear();
            for (FieldSyncPacket.DoorEntry de : e.doors) {
                ClientDoor d = new ClientDoor();
                d.dx = de.dx; d.dy = de.dy; d.dz = de.dz;
                d.open = de.open - offset;
                d.expire = de.expire - offset;
                f.doors.add(d);
                boolean known = false;
                for (ClientDoor od : oldDoors) {
                    if (od.open == d.open) {
                        known = true;
                        break;
                    }
                }
                if (!known) {
                    spawnDoorSparks(level, f, d);
                }
            }
            next.put(f.id, f);
        }
        FIELDS.clear();
        FIELDS.putAll(next);
    }

    private static void spawnDoorSparks(ClientLevel level, ClientField f, ClientDoor d) {
        Vec3 c = f.center(level, 0.0f);
        double[] t1 = com.dedsafio.mod.util.DoorMath.tangent1(d.dx, d.dy, d.dz);
        double[] t2 = com.dedsafio.mod.util.DoorMath.tangent2(d.dx, d.dy, d.dz, t1);
        double h = f.doorSize / 2.0;
        double fwd = Math.sqrt(Math.max(1.0, (double) f.radius * f.radius - 2.0 * h * h));
        for (int i = 0; i < 24; i++) {
            double a = (level.random.nextDouble() * 2.0 - 1.0) * h;
            double b = (level.random.nextDouble() * 2.0 - 1.0) * h;
            // sobre el borde del cuadrado
            if (level.random.nextBoolean()) {
                a = a >= 0 ? h : -h;
            } else {
                b = b >= 0 ? h : -h;
            }
            double px = c.x + d.dx * fwd + t1[0] * a + t2[0] * b;
            double py = c.y + d.dy * fwd + t1[1] * a + t2[1] * b;
            double pz = c.z + d.dz * fwd + t1[2] * a + t2[2] * b;
            level.addParticle(ModParticles.SPARK.get(), px, py, pz,
                    d.dx * 0.03 + (level.random.nextDouble() - 0.5) * 0.04,
                    d.dy * 0.03 + (level.random.nextDouble() - 0.5) * 0.04,
                    d.dz * 0.03 + (level.random.nextDouble() - 0.5) * 0.04);
        }
    }

    /** Campo (de la dimension actual) que contiene al jugador local, o null. */
    public static ClientField insideField(ClientLevel level, Vec3 pos, float pt) {
        ClientField best = null;
        double bestD = Double.MAX_VALUE;
        for (ClientField f : FIELDS.values()) {
            Vec3 c = f.center(level, pt);
            double d = c.distanceToSqr(pos);
            if (d < (double) f.radius * f.radius && d < bestD) {
                best = f;
                bestD = d;
            }
        }
        return best;
    }

    public static ClientField nearest(ClientLevel level, Vec3 pos) {
        ClientField best = null;
        double bestD = Double.MAX_VALUE;
        for (ClientField f : FIELDS.values()) {
            double d = f.center(level, 0.0f).distanceToSqr(pos);
            if (d < bestD) {
                bestD = d;
                best = f;
            }
        }
        return best;
    }
}
