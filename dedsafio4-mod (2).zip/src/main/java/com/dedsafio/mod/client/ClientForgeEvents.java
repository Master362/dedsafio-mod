package com.dedsafio.mod.client;

import com.dedsafio.mod.DedsafioMod;
import com.dedsafio.mod.registry.ModParticles;
import com.dedsafio.mod.server.MindSpaceManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos del bus de Forge que solo existen en el cliente. */
@Mod.EventBusSubscriber(modid = DedsafioMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        ForceFieldRenderer.render(event);
    }

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Post event) {
        DialogueRenderer.render(event);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        float a = WarpOverlay.amount((float) event.getPartialTick());
        if (a > 0.0f) {
            event.setFOV(event.getFOV() + 35.0 * a);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientFields.clear();
        DialogueRenderer.clear();
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        WarpOverlay.tick();
        DialogueRenderer.tick();
        while (ClientModEvents.PANEL_KEY.consumeClick()) {
            if (mc.screen == null && mc.player != null) {
                mc.setScreen(new StaffPanelScreen());
            }
        }
        // ambiente astral: chispas que flotan en el Espacio mental
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level != null && p != null && level.dimension().equals(MindSpaceManager.MIND_SPACE) && !mc.isPaused()) {
            for (int i = 0; i < 2; i++) {
                double x = p.getX() + (level.random.nextDouble() - 0.5) * 40.0;
                double y = p.getY() + (level.random.nextDouble() - 0.4) * 20.0;
                double z = p.getZ() + (level.random.nextDouble() - 0.5) * 40.0;
                level.addParticle(ModParticles.SPARK.get(), x, y, z, 0.0, 0.01 + level.random.nextDouble() * 0.02, 0.0);
            }
        }
    }
}
