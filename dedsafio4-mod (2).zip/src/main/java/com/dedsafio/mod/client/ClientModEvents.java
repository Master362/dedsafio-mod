package com.dedsafio.mod.client;

import com.dedsafio.mod.DedsafioMod;
import com.dedsafio.mod.particle.SparkParticle;
import com.dedsafio.mod.registry.ModParticles;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.IOException;

/** Registro de cosas de cliente en el bus del mod: shader, particulas, teclas y overlays de interfaz. */
@Mod.EventBusSubscriber(modid = DedsafioMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    public static ShaderInstance warpShader;
    public static final KeyMapping PANEL_KEY =
            new KeyMapping("key.dedsafio4.panel", InputConstants.KEY_J, "key.categories.dedsafio4");

    private ClientModEvents() {}

    @SubscribeEvent
    public static void onRegisterShaders(RegisterShadersEvent event) throws IOException {
        event.registerShader(new ShaderInstance(event.getResourceProvider(),
                new ResourceLocation(DedsafioMod.MODID, "warp_vortex"), DefaultVertexFormat.POSITION_TEX),
                shader -> warpShader = shader);
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(PANEL_KEY);
    }

    @SubscribeEvent
    public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.SPARK.get(), SparkParticle.Provider::new);
    }

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("field_hud", (gui, g, pt, w, h) -> FieldHud.render(g, pt, w, h));
        event.registerAboveAll("warp_void", (gui, g, pt, w, h) -> WarpOverlay.render(g, pt, w, h));
    }
}
