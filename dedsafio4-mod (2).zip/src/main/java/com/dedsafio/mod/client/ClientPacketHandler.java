package com.dedsafio.mod.client;

import com.dedsafio.mod.net.DialoguePacket;
import com.dedsafio.mod.net.FieldSyncPacket;
import com.dedsafio.mod.net.HitPacket;
import com.dedsafio.mod.net.WarpPacket;
import com.dedsafio.mod.registry.ModParticles;
import com.dedsafio.mod.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Receptor de paquetes en el cliente (solo se carga en Dist.CLIENT). */
public final class ClientPacketHandler {
    private ClientPacketHandler() {}

    public static void onFieldSync(FieldSyncPacket p) {
        ClientFields.apply(p);
    }

    public static void onHit(HitPacket p) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        ClientFields.ClientField f = ClientFields.FIELDS.get(p.fieldId);
        if (f == null) {
            return;
        }
        float now = level.getGameTime();
        Vec3 c = f.center(level, 0.0f);
        Vec3 dir = new Vec3(p.dx, p.dy, p.dz);
        Vec3 at = c.add(dir.scale(f.radius));
        if (p.broken) {
            boolean expired = p.strength < 0.0f;
            level.playLocalSound(at.x, at.y, at.z, ModSounds.FIELD_BREAK.get(), SoundSource.PLAYERS,
                    expired ? 1.5f : 4.0f, expired ? 0.7f : 1.0f, false);
            int n = expired ? 60 : 160;
            for (int i = 0; i < n; i++) {
                Vec3 r = new Vec3(level.random.nextGaussian(), level.random.nextGaussian(), level.random.nextGaussian());
                if (r.lengthSqr() < 1.0E-6) {
                    continue;
                }
                r = r.normalize();
                Vec3 pp = c.add(r.scale(f.radius));
                level.addParticle(ModParticles.SPARK.get(), pp.x, pp.y, pp.z, r.x * 0.08, r.y * 0.08, r.z * 0.08);
            }
            ClientFields.FIELDS.remove(f.id);
            return;
        }
        f.hitTime = now;
        f.hx = p.dx; f.hy = p.dy; f.hz = p.dz;
        f.hitStrength = Math.max(0.3f, p.strength) * 1.4f;
        level.playLocalSound(at.x, at.y, at.z, ModSounds.FIELD_HIT.get(), SoundSource.PLAYERS,
                0.6f + p.strength, 0.9f + level.random.nextFloat() * 0.2f, false);
        int n = 6 + (int) (p.strength * 20.0f);
        for (int i = 0; i < n; i++) {
            level.addParticle(ModParticles.SPARK.get(), at.x, at.y, at.z,
                    (level.random.nextDouble() - 0.5) * 0.25, (level.random.nextDouble() - 0.5) * 0.25,
                    (level.random.nextDouble() - 0.5) * 0.25);
        }
    }

    public static void onDialogue(DialoguePacket p) {
        DialogueRenderer.add(p);
        ClientLevel level = Minecraft.getInstance().level;
        if (level != null && level.getEntity(p.entityId) != null) {
            var e = level.getEntity(p.entityId);
            level.playLocalSound(e.getX(), e.getY() + e.getBbHeight(), e.getZ(), ModSounds.BUBBLE.get(),
                    SoundSource.PLAYERS, 0.5f, 1.0f, false);
        }
    }

    public static void onWarp(WarpPacket p) {
        WarpOverlay.start(p.durationTicks, p.intensity, p.color);
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.WARP.get(), 1.0f));
    }
}
