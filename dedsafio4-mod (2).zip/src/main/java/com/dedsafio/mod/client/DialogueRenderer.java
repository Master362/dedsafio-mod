package com.dedsafio.mod.client;

import com.dedsafio.mod.DedsafioMod;
import com.dedsafio.mod.net.DialoguePacket;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderPlayerEvent;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Nube de dialogo sobre la cabeza del jugador con el mensaje que envio al chat. */
public final class DialogueRenderer {
    private static final ResourceLocation BUBBLE = new ResourceLocation(DedsafioMod.MODID, "textures/gui/bubble.png");
    private static final ResourceLocation TAIL = new ResourceLocation(DedsafioMod.MODID, "textures/gui/bubble_tail.png");

    private static final class Bubble {
        String text;
        float start;
        int duration;
        int bubbleColor, textColor;
        float scale, yOffset;
        int maxWidth;
        List<FormattedCharSequence> lines;
        int textW;
    }

    private static final Map<Integer, Bubble> BUBBLES = new HashMap<>();
    private static int ticks = 0;

    private DialogueRenderer() {}

    public static void tick() {
        ticks++;
        BUBBLES.values().removeIf(b -> ticks - b.start > b.duration + 2);
    }

    public static void clear() {
        BUBBLES.clear();
    }

    public static void add(DialoguePacket p) {
        Bubble b = new Bubble();
        b.text = p.text;
        b.start = ticks;
        b.duration = p.durationTicks;
        b.bubbleColor = p.bubbleColor;
        b.textColor = p.textColor;
        b.scale = p.scale;
        b.yOffset = p.yOffset;
        b.maxWidth = p.maxWidth;
        BUBBLES.put(p.entityId, b);
    }

    public static void render(RenderPlayerEvent.Post event) {
        Player player = event.getEntity();
        Bubble b = BUBBLES.get(player.getId());
        if (b == null) {
            return;
        }
        float age = ticks + event.getPartialTick() - b.start;
        if (age < 0.0f || age >= b.duration) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        if (b.lines == null) {
            b.lines = font.split(Component.literal(b.text), b.maxWidth);
            int w = 0;
            for (FormattedCharSequence l : b.lines) {
                w = Math.max(w, font.width(l));
            }
            b.textW = w;
        }
        float alpha = age > b.duration - 10 ? Math.max(0.0f, (b.duration - age) / 10.0f) : 1.0f;
        float pop = 1.0f;
        if (age < 6.0f) {
            float x = age / 6.0f - 1.0f;
            pop = 1.0f + 2.70158f * x * x * x + 1.70158f * x * x;
        }

        PoseStack ps = event.getPoseStack();
        MultiBufferSource buf = event.getMultiBufferSource();
        ps.pushPose();
        ps.translate(0.0, player.getBbHeight() + 0.75 + b.yOffset, 0.0);
        ps.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        float sc = 0.025f * b.scale * Math.max(0.01f, pop);
        ps.scale(-sc, -sc, sc);
        Matrix4f m = ps.last().pose();

        int padX = 8, padY = 6, lineH = 10, c = 10;
        float w = Math.max(24.0f, b.textW + padX * 2);
        float h = Math.max(20.0f, b.lines.size() * lineH + padY * 2 - 1);
        float tailH = 13.0f;
        float x0 = -w / 2.0f, x1 = w / 2.0f;
        float y1 = -tailH + 2.0f, y0 = y1 - h;
        int light = LightTexture.FULL_BRIGHT;
        int cr = (b.bubbleColor >> 16) & 255, cg = (b.bubbleColor >> 8) & 255, cb = b.bubbleColor & 255;
        int ca = (int) (alpha * 255.0f);

        VertexConsumer vc = buf.getBuffer(RenderType.text(BUBBLE));
        float[] xs = {x0, x0 + c, x1 - c, x1};
        float[] ys = {y0, y0 + c, y1 - c, y1};
        float[] us = {0.0f, 16.0f / 48.0f, 32.0f / 48.0f, 1.0f};
        for (int iy = 0; iy < 3; iy++) {
            for (int ix = 0; ix < 3; ix++) {
                quad(vc, m, xs[ix], ys[iy], xs[ix + 1], ys[iy + 1], us[ix], us[iy], us[ix + 1], us[iy + 1], cr, cg, cb, ca, light);
            }
        }
        VertexConsumer tv = buf.getBuffer(RenderType.text(TAIL));
        float tx = x0 + w * 0.22f;
        quad(tv, m, tx - 6.0f, y1 - 3.0f, tx + 8.0f, y1 + 11.0f, 0.0f, 0.0f, 1.0f, 1.0f, cr, cg, cb, ca, light);

        int tc = (b.textColor & 0xFFFFFF) | (Math.max(8, ca) << 24);
        for (int i = 0; i < b.lines.size(); i++) {
            FormattedCharSequence line = b.lines.get(i);
            float lx = -font.width(line) / 2.0f;
            font.drawInBatch(line, lx, y0 + padY + i * lineH, tc, false, m, buf, Font.DisplayMode.NORMAL, 0, light);
        }
        ps.popPose();
    }

    private static void quad(VertexConsumer vc, Matrix4f m, float x0, float y0, float x1, float y1,
                             float u0, float v0, float u1, float v1, int r, int g, int b, int a, int light) {
        vc.vertex(m, x0, y0, 0.0f).color(r, g, b, a).uv(u0, v0).uv2(light).endVertex();
        vc.vertex(m, x0, y1, 0.0f).color(r, g, b, a).uv(u0, v1).uv2(light).endVertex();
        vc.vertex(m, x1, y1, 0.0f).color(r, g, b, a).uv(u1, v1).uv2(light).endVertex();
        vc.vertex(m, x1, y0, 0.0f).color(r, g, b, a).uv(u1, v0).uv2(light).endVertex();
    }
}
