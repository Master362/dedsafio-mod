package com.dedsafio.mod.client;

import com.dedsafio.mod.DedsafioMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** Barra de resistencia y tiempo restante cuando estas dentro de un campo de Revil. */
public final class FieldHud {
    private static final ResourceLocation ICON = new ResourceLocation(DedsafioMod.MODID, "textures/gui/hex_icon.png");

    private FieldHud() {}

    public static void render(GuiGraphics g, float pt, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui || ClientFields.FIELDS.isEmpty()) {
            return;
        }
        ClientFields.ClientField f = ClientFields.insideField(mc.level, mc.player.getEyePosition(pt), pt);
        if (f == null) {
            return;
        }
        int bw = 120, bh = 7;
        int x = w / 2 - bw / 2;
        int y = 22;
        float frac = Math.max(0.0f, Math.min(1.0f, f.resistance / Math.max(1.0f, f.maxResistance)));
        g.fill(x - 1, y - 1, x + bw + 1, y + bh + 1, 0xCC12081E);
        g.fill(x, y, x + bw, y + bh, 0xFF2A1040);
        int fillW = (int) (bw * frac);
        int col = 0xFF000000 | lerp(f.color2, f.color1, frac);
        g.fill(x, y, x + fillW, y + bh, col);
        g.fill(x, y, x + fillW, y + 2, 0x55FFFFFF);
        g.blit(ICON, x - 20, y - 5, 0, 0, 16, 16, 16, 16);
        String time = "";
        if (f.end >= 0) {
            long left = Math.max(0L, (f.end - mc.level.getGameTime()) / 20L);
            time = "  " + (left / 60) + ":" + String.format("%02d", left % 60);
        }
        g.drawCenteredString(mc.font, Component.translatable("hud.dedsafio4.field").append(
                Component.literal("  " + (int) f.resistance + "/" + (int) f.maxResistance + time)), w / 2, y + bh + 3, 0xE9D8FF);
    }

    private static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (gr << 8) | bl;
    }
}
