package com.dedsafio.mod.client;

import com.dedsafio.mod.client.ClientFields.ClientDoor;
import com.dedsafio.mod.client.ClientFields.ClientField;
import com.dedsafio.mod.util.DoorMath;
import com.dedsafio.mod.util.HexSphere;
import com.dedsafio.mod.util.PolyClip;
import com.dedsafio.mod.util.PolyClip.Vx;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Dibuja el campo de fuerza de Revil: cupula geodesica de hexagonos translucidos con bordes luminosos
 * (como en la imagen de referencia), ondulaciones al recibir golpes y la puertita cuadrada abierta.
 */
public final class ForceFieldRenderer {
    private ForceFieldRenderer() {}

    private static final class DoorGeo {
        double[] c, t1, t2;
        double h;
        float progress;
    }

    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }
        if (ClientFields.FIELDS.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        float pt = event.getPartialTick();
        float now = level.getGameTime() + pt;
        Vec3 cam = event.getCamera().getPosition();
        Matrix4f m = event.getPoseStack().last().pose();

        List<Prepared> list = new ArrayList<>();
        for (ClientField f : ClientFields.FIELDS.values()) {
            Prepared p = prepare(level, f, now, pt, cam);
            if (p != null) {
                list.add(p);
            }
        }
        if (list.isEmpty()) {
            return;
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();

        // pasada 1: relleno translucido de las celdas
        bb.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        for (Prepared p : list) {
            emitFill(bb, m, p, now);
        }
        BufferUploader.drawWithShader(bb.end());

        // pasada 2: bordes y marco de la puerta con brillo aditivo
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        bb.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        for (Prepared p : list) {
            emitEdges(bb, m, p, now);
        }
        BufferUploader.drawWithShader(bb.end());

        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------------------------ preparacion

    private static final class Prepared {
        ClientField f;
        double ox, oy, oz;      // centro - camara
        double radius;
        float alphaMul;
        float time;
        List<DoorGeo> doors = new ArrayList<>();
        HexSphere hs;
    }

    private static Prepared prepare(ClientLevel level, ClientField f, float now, float pt, Vec3 cam) {
        float age = now - f.spawnTime;
        float g = Math.min(1.0f, Math.max(0.0f, age / 15.0f));
        if (g <= 0.01f) {
            return null;
        }
        float grow = 1.0f - (1.0f - g) * (1.0f - g) * (1.0f - g);
        float fade = 1.0f;
        if (f.end >= 0) {
            fade = Math.min(1.0f, Math.max(0.0f, (f.end - now) / 20.0f));
            if (fade <= 0.0f) {
                return null;
            }
        }
        Vec3 c = f.center(level, pt);
        Prepared p = new Prepared();
        p.f = f;
        p.ox = c.x - cam.x;
        p.oy = c.y - cam.y;
        p.oz = c.z - cam.z;
        p.radius = f.radius * grow;
        p.alphaMul = fade;
        p.time = now / 20.0f;
        p.hs = HexSphere.get(f.radius >= 20.0f ? 3 : 2);
        for (ClientDoor d : f.doors) {
            float prog = DoorMath.progress(d.open, d.expire, now);
            double h = f.doorSize / 2.0 * prog;
            if (h < 0.03) {
                continue;
            }
            DoorGeo dg = new DoorGeo();
            dg.c = new double[] {d.dx, d.dy, d.dz};
            dg.t1 = DoorMath.tangent1(d.dx, d.dy, d.dz);
            dg.t2 = DoorMath.tangent2(d.dx, d.dy, d.dz, dg.t1);
            dg.h = h;
            dg.progress = prog;
            p.doors.add(dg);
        }
        return p;
    }

    // ------------------------------------------------------------------ emision

    private static float ripple(ClientField f, double[] dir, float now) {
        float age = now - f.hitTime;
        if (age < 0.0f || age > 50.0f) {
            return 0.0f;
        }
        double cos = Math.max(-1.0, Math.min(1.0, dir[0] * f.hx + dir[1] * f.hy + dir[2] * f.hz));
        double ang = Math.acos(cos);
        double ring = age * 0.13;
        double amp = Math.exp(-age / 14.0) * f.hitStrength;
        double r1 = Math.exp(-Math.pow((ang - ring) / 0.3, 2.0));
        double r2 = 1.2 * Math.exp(-Math.pow(ang / 0.45, 2.0)) * Math.exp(-age / 6.0);
        return (float) (amp * (r1 + r2));
    }

    private static float[] rgb(int c) {
        return new float[] {((c >> 16) & 255) / 255.0f, ((c >> 8) & 255) / 255.0f, (c & 255) / 255.0f};
    }

    private static void emitFill(BufferBuilder b, Matrix4f m, Prepared p, float now) {
        ClientField f = p.f;
        float[] ca = rgb(f.color1), cb = rgb(f.color2);
        HexSphere hs = p.hs;
        double R = p.radius;
        for (int i = 0; i < hs.cellCount; i++) {
            float rnd = hs.rnd[i];
            double[] c = hs.centers[i];
            float shimmer = 0.78f + 0.22f * (float) Math.sin(p.time * 1.6f * f.pulse + rnd * 6.2831f);
            float rip = ripple(f, c, now);
            float base = f.opacity * shimmer * p.alphaMul;
            float tr = ca[0] + (cb[0] - ca[0]) * rnd;
            float tg = ca[1] + (cb[1] - ca[1]) * rnd;
            float tb = ca[2] + (cb[2] - ca[2]) * rnd;
            float lighten = Math.min(1.0f, 0.3f + rip * 0.5f);
            Vx center = new Vx(c[0] * R, c[1] * R, c[2] * R, tr * 0.55f, tg * 0.55f, tb * 0.55f,
                    Math.min(1.0f, base * 0.75f + rip * 0.15f * p.alphaMul));
            double[][] poly = hs.polys[i];
            int n = poly.length;
            for (int k = 0; k < n; k++) {
                double[] a = poly[k], q = poly[(k + 1) % n];
                List<Vx> tri = new ArrayList<>(3);
                tri.add(center);
                tri.add(rim(a, R, tr, tg, tb, lighten, Math.min(1.0f, base * 1.35f + rip * 0.3f * p.alphaMul)));
                tri.add(rim(q, R, tr, tg, tb, lighten, Math.min(1.0f, base * 1.35f + rip * 0.3f * p.alphaMul)));
                emitPoly(b, m, tri, p);
            }
        }
    }

    private static Vx rim(double[] u, double R, float r, float g, float bl, float lighten, float a) {
        return new Vx(u[0] * R, u[1] * R, u[2] * R, r + (1.0f - r) * lighten, g + (1.0f - g) * lighten, bl + (1.0f - bl) * lighten, a);
    }

    private static void emitEdges(BufferBuilder b, Matrix4f m, Prepared p, float now) {
        ClientField f = p.f;
        float[] ca = rgb(f.color1), cb = rgb(f.color2);
        double R = p.radius * 1.002;
        double w = Math.max(0.01, f.edge);
        for (double[][] e : p.hs.edges) {
            double[] mid = {e[0][0] + e[1][0], e[0][1] + e[1][1], e[0][2] + e[1][2]};
            double ml = Math.sqrt(mid[0] * mid[0] + mid[1] * mid[1] + mid[2] * mid[2]);
            mid[0] /= ml; mid[1] /= ml; mid[2] /= ml;
            float rip = ripple(f, mid, now);
            float pulse = 0.8f + 0.2f * (float) Math.sin(p.time * 2.0f * f.pulse + mid[0] * 5.0 + mid[2] * 3.0);
            float a = Math.min(1.0f, (0.75f * pulse + rip * 0.6f) * p.alphaMul);
            float mix = Math.min(1.0f, 0.75f + rip * 0.25f);
            float cr = ca[0] + (1.0f - ca[0]) * mix, cg = ca[1] + (1.0f - ca[1]) * mix, cbl = ca[2] + (1.0f - ca[2]) * mix;
            emitSegment(b, m, p, e[0], e[1], R, w, cr, cg, cbl, a);                               // nucleo blanco
            emitSegment(b, m, p, e[0], e[1], R, w * 5.0, cb[0], cb[1], cb[2], 0.16f * p.alphaMul + rip * 0.2f * p.alphaMul); // halo
        }
        for (DoorGeo d : p.doors) {
            emitDoorFrame(b, m, p, d, ca, cb);
        }
    }

    private static void emitSegment(BufferBuilder b, Matrix4f m, Prepared p, double[] u0, double[] u1, double R, double width,
                                    float r, float g, float bl, float a) {
        double ax = u0[0] * R, ay = u0[1] * R, az = u0[2] * R;
        double bx = u1[0] * R, by = u1[1] * R, bz = u1[2] * R;
        quadBetween(b, m, p, ax, ay, az, bx, by, bz, width, r, g, bl, a);
    }

    /** Cinta de ancho 'width' entre dos puntos de la esfera (relativos al centro). */
    private static void quadBetween(BufferBuilder b, Matrix4f m, Prepared p, double ax, double ay, double az,
                                    double bx, double by, double bz, double width, float r, float g, float bl, float a) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double mx = (ax + bx) / 2.0, my = (ay + by) / 2.0, mz = (az + bz) / 2.0;
        double ml = Math.sqrt(mx * mx + my * my + mz * mz);
        if (ml < 1.0E-6) {
            return;
        }
        double nx = mx / ml, ny = my / ml, nz = mz / ml;
        double sx = ny * dz - nz * dy, sy = nz * dx - nx * dz, sz = nx * dy - ny * dx;
        double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1.0E-9) {
            return;
        }
        double k = width / 2.0 / sl;
        sx *= k; sy *= k; sz *= k;
        List<Vx> quad = new ArrayList<>(4);
        quad.add(new Vx(ax - sx, ay - sy, az - sz, r, g, bl, a));
        quad.add(new Vx(ax + sx, ay + sy, az + sz, r, g, bl, a));
        quad.add(new Vx(bx + sx, by + sy, bz + sz, r, g, bl, a));
        quad.add(new Vx(bx - sx, by - sy, bz - sz, r, g, bl, a));
        emitPoly(b, m, quad, p);
    }

    private static void emitDoorFrame(BufferBuilder b, Matrix4f m, Prepared p, DoorGeo d, float[] ca, float[] cb) {
        double R = p.radius * 1.003;
        double h = d.h;
        double fwd = Math.sqrt(Math.max(1.0, R * R - 2.0 * h * h));
        double[][] corner = new double[4][3];
        int[][] sg = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (int i = 0; i < 4; i++) {
            for (int k = 0; k < 3; k++) {
                corner[i][k] = d.c[k] * fwd + d.t1[k] * h * sg[i][0] + d.t2[k] * h * sg[i][1];
            }
        }
        float pulse = 0.85f + 0.15f * (float) Math.sin(p.time * 9.0f);
        float a = Math.min(1.0f, d.progress * pulse * p.alphaMul);
        double fw = Math.max(0.05, p.f.edge * 2.4);
        List<Vx> glow = new ArrayList<>(4);
        for (int i = 0; i < 4; i++) {
            glow.add(new Vx(corner[i][0], corner[i][1], corner[i][2], 0.85f, 0.95f, 1.0f, 0.10f * d.progress * p.alphaMul));
        }
        emitRaw(b, m, glow, p);   // el interior de la puerta no se recorta a si mismo
        for (int i = 0; i < 4; i++) {
            double[] s = corner[i], e = corner[(i + 1) % 4];
            rawQuadBetween(b, m, p, s, e, fw, 0.9f, 0.97f, 1.0f, a);
            rawQuadBetween(b, m, p, s, e, fw * 4.0, cb[0], cb[1], cb[2], 0.25f * a);
        }
    }

    private static void rawQuadBetween(BufferBuilder b, Matrix4f m, Prepared p, double[] s, double[] e, double width,
                                       float r, float g, float bl, float a) {
        double dx = e[0] - s[0], dy = e[1] - s[1], dz = e[2] - s[2];
        double mx = (s[0] + e[0]) / 2.0, my = (s[1] + e[1]) / 2.0, mz = (s[2] + e[2]) / 2.0;
        double ml = Math.sqrt(mx * mx + my * my + mz * mz);
        double nx = mx / ml, ny = my / ml, nz = mz / ml;
        double sx = ny * dz - nz * dy, sy = nz * dx - nx * dz, sz = nx * dy - ny * dx;
        double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1.0E-9) {
            return;
        }
        double k = width / 2.0 / sl;
        sx *= k; sy *= k; sz *= k;
        List<Vx> q = new ArrayList<>(4);
        q.add(new Vx(s[0] - sx, s[1] - sy, s[2] - sz, r, g, bl, a));
        q.add(new Vx(s[0] + sx, s[1] + sy, s[2] + sz, r, g, bl, a));
        q.add(new Vx(e[0] + sx, e[1] + sy, e[2] + sz, r, g, bl, a));
        q.add(new Vx(e[0] - sx, e[1] - sy, e[2] - sz, r, g, bl, a));
        emitRaw(b, m, q, p);
    }

    /** Emite un poligono restando las puertas abiertas. */
    private static void emitPoly(BufferBuilder b, Matrix4f m, List<Vx> poly, Prepared p) {
        if (p.doors.isEmpty()) {
            emitRaw(b, m, poly, p);
            return;
        }
        List<List<Vx>> pieces = new ArrayList<>();
        pieces.add(poly);
        for (DoorGeo d : p.doors) {
            List<List<Vx>> next = new ArrayList<>();
            for (List<Vx> piece : pieces) {
                PolyClip.subtractDoor(piece, d.c, d.t1, d.t2, d.h, next);
            }
            pieces = next;
        }
        for (List<Vx> piece : pieces) {
            emitRaw(b, m, piece, p);
        }
    }

    private static void emitRaw(BufferBuilder b, Matrix4f m, List<Vx> poly, Prepared p) {
        int n = poly.size();
        for (int i = 1; i < n - 1; i++) {
            vertex(b, m, poly.get(0), p);
            vertex(b, m, poly.get(i), p);
            vertex(b, m, poly.get(i + 1), p);
        }
    }

    private static void vertex(BufferBuilder b, Matrix4f m, Vx v, Prepared p) {
        b.vertex(m, (float) (v.x + p.ox), (float) (v.y + p.oy), (float) (v.z + p.oz))
                .color(clamp01(v.r), clamp01(v.g), clamp01(v.b), clamp01(v.a)).endVertex();
    }

    private static float clamp01(float v) {
        return v < 0.0f ? 0.0f : Math.min(v, 1.0f);
    }
}
