package com.dedsafio.mod.client;

import com.dedsafio.mod.DedsafioMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** Panel del staff (tecla J): botones que ejecutan los comandos /dedsafio. El servidor valida los permisos. */
public class StaffPanelScreen extends Screen {
    private static final ResourceLocation PANEL = new ResourceLocation(DedsafioMod.MODID, "textures/gui/panel.png");
    private static final int W = 230, H = 214;
    private int ax, ay;

    public StaffPanelScreen() {
        super(Component.translatable("gui.dedsafio4.panel"));
    }

    private void cmd(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.connection.sendCommand(command);
        }
    }

    private Button btn(int col, int y, int width, Component label, Button.OnPress press) {
        int x = ax + 9 + col * 72;
        return this.addRenderableWidget(Button.builder(label, press).bounds(x, ay + y, width, 20).build());
    }

    @Override
    protected void init() {
        ax = (this.width - W) / 2;
        ay = (this.height - H) / 2;
        // --- Campo de Revil
        btn(0, 32, 68, Component.translatable("gui.dedsafio4.create"), b -> cmd("dedsafio forcefield create"));
        btn(1, 32, 68, Component.translatable("gui.dedsafio4.remove"), b -> cmd("dedsafio forcefield remove nearest"));
        btn(2, 32, 68, Component.translatable("gui.dedsafio4.heal"), b -> cmd("dedsafio forcefield heal nearest"));
        btn(0, 54, 68, Component.translatable("gui.dedsafio4.radius_up"), b -> changeRadius(2.0f));
        btn(1, 54, 68, Component.translatable("gui.dedsafio4.radius_down"), b -> changeRadius(-2.0f));
        btn(2, 54, 68, Component.translatable("gui.dedsafio4.resist_up"), b -> {
            ClientFields.ClientField f = nearest();
            if (f != null) {
                cmd("dedsafio forcefield set nearest resistance " + (int) (f.maxResistance + 50.0f));
            }
        });
        btn(0, 76, 68, Component.literal("ON"), b -> cmd("dedsafio forcefield enable"));
        btn(1, 76, 68, Component.literal("OFF"), b -> cmd("dedsafio forcefield disable"));
        // --- Espacio mental
        btn(0, 116, 68, Component.translatable("gui.dedsafio4.travel"), b -> cmd("dedsafio void travel"));
        btn(1, 116, 68, Component.translatable("gui.dedsafio4.return"), b -> cmd("dedsafio void travel"));
        btn(0, 138, 68, Component.literal("ON"), b -> cmd("dedsafio void enable"));
        btn(1, 138, 68, Component.literal("OFF"), b -> cmd("dedsafio void disable"));
        // --- Dialogos
        btn(0, 178, 68, Component.translatable("gui.dedsafio4.test_bubble"), b -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                cmd("dedsafio dialogue say " + mc.player.getGameProfile().getName() + " Hola desde el panel del staff");
            }
        });
        btn(1, 178, 68, Component.literal("ON"), b -> cmd("dedsafio dialogue enable"));
        btn(2, 178, 68, Component.literal("OFF"), b -> cmd("dedsafio dialogue disable"));
    }

    private ClientFields.ClientField nearest() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return null;
        }
        return ClientFields.nearest(mc.level, mc.player.position());
    }

    private void changeRadius(float delta) {
        ClientFields.ClientField f = nearest();
        if (f == null) {
            return;
        }
        float r = Math.max(2.0f, f.radius + delta);
        cmd("dedsafio forcefield set nearest radius " + r);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float pt) {
        this.renderBackground(g);
        g.blit(PANEL, ax, ay, 0, 0, W, H, 256, 256);
        g.drawCenteredString(this.font, this.title, ax + W / 2, ay + 8, 0xF2E6FF);
        g.drawString(this.font, Component.translatable("gui.dedsafio4.section.field"), ax + 10, ay + 21, 0xFF8FC0, false);
        g.drawString(this.font, Component.translatable("gui.dedsafio4.section.void"), ax + 10, ay + 105, 0xC9A0FF, false);
        g.drawString(this.font, Component.translatable("gui.dedsafio4.section.dialogue"), ax + 10, ay + 167, 0xA0E0FF, false);
        super.render(g, mouseX, mouseY, pt);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
