package com.dedsafio.mod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.ShaderInstance;
import org.joml.Matrix4f;

/**
 * Transicion del viaje dimensional: vacio negro con destellos blancos que salen del centro hacia los bordes.
 * Se dibuja con un shader GLSL real (assets/dedsafio4/shaders/core/warp_vortex.*).
 */
public final class WarpOverlay {
    private static boolean active = false;
    private static int age = 0;
    private static int total = 100;
    private static float intensity = 1.0f;
    private static float tr = 1.0f, tg = 1.0f, tb = 1.0f;
    private static double accum = 0.0;

    private WarpOverlay() {}

    public static void start(int durationTicks, float inten, int color) {
        active = true;
        age = 0;
        total = Math.max(10, durationTicks);
        intensity = inten;
        tr = ((color >> 16) & 255) / 255.0f;
        tg = ((color >> 8) & 255) / 255.0f;
        tb = (color & 255) / 255.0f;
        accum = 0.0;
    }

    public static boolean isActive() {
        return active;
    }

    private static float speed(float t) {
        return intensity * (0.5f + 2.5f * (float) Math.sin(Math.PI * Math.min(1.0f, Math.max(0.0f, t))));
    }

    private static float fade(float t) {
        if (t < 0.2f) return t / 0.2f;
        if (t > 0.8f) return (1.0f - t) / 0.2f;
        return 1.0f;
    }

    public static void tick() {
        if (!active) {
            return;
        }
        accum += speed((float) age / total) / 20.0 * 3.0;
        age++;
        if (age >= total) {
            active = false;
        }
    }

    /** 0..1: cuanto efecto hay ahora (para el FOV). */
    public static float amount(float pt) {
        if (!active) {
            return 0.0f;
        }
        float t = (age + pt) / total;
        return fade(t) * (0.3f + 0.7f * (float) Math.sin(Math.PI * Math.min(1.0f, t)));
    }

    public static void render(GuiGraphics g, float pt, int w, int h) {
        if (!active) {
            return;
        }
        float t = Math.min(1.0f, (age + pt) / total);
        float fade = fade(t);
        ShaderInstance sh = ClientModEvents.warpShader;
        if (sh == null) {
            int a = Math.min(255, Math.max(0, (int) (fade * 255.0f)));
            g.fill(0, 0, w, h, a << 24);
            return;
        }
        double time = accum + speed(t) / 20.0 * 3.0 * pt;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(() -> sh);
        sh.safeGetUniform("Time").set((float) time);
        sh.safeGetUniform("Fade").set(fade);
        sh.safeGetUniform("Aspect").set((float) w / (float) Math.max(1, h));
        sh.safeGetUniform("Tint").set(tr, tg, tb);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        bb.vertex(m, 0.0f, (float) h, 0.0f).uv(0.0f, 1.0f).endVertex();
        bb.vertex(m, (float) w, (float) h, 0.0f).uv(1.0f, 1.0f).endVertex();
        bb.vertex(m, (float) w, 0.0f, 0.0f).uv(1.0f, 0.0f).endVertex();
        bb.vertex(m, 0.0f, 0.0f, 0.0f).uv(0.0f, 0.0f).endVertex();
        BufferUploader.drawWithShader(bb.end());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}
