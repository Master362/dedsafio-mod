package com.dedsafio.mod.command;

import com.dedsafio.mod.data.Access;
import com.dedsafio.mod.data.DedData;
import com.dedsafio.mod.data.FieldConfig;
import com.dedsafio.mod.data.ForceField;
import com.dedsafio.mod.data.Mechanic;
import com.dedsafio.mod.data.ModSettings;
import com.dedsafio.mod.server.DialogueManager;
import com.dedsafio.mod.server.ForceFieldManager;
import com.dedsafio.mod.server.MindSpaceManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * /dedsafio  (requiere permiso 2 = staff)
 *   forcefield | void | dialogue | permissions | status
 */
public final class DedsafioCommand {
    private DedsafioCommand() {}

    private interface Creator {
        int run(CommandContext<CommandSourceStack> c, Float radius, Float resistance, Integer seconds) throws CommandSyntaxException;
    }

    private static final SuggestionProvider<CommandSourceStack> FIELD_PROPS =
            (c, b) -> SharedSuggestionProvider.suggest(FieldConfig.PROPERTIES, b);
    private static final SuggestionProvider<CommandSourceStack> FF_DEFAULT_PROPS = (c, b) -> {
        List<String> l = new ArrayList<>(FieldConfig.PROPERTIES);
        l.addAll(ModSettings.FF_GLOBAL);
        return SharedSuggestionProvider.suggest(l, b);
    };
    private static final SuggestionProvider<CommandSourceStack> VOID_PROPS =
            (c, b) -> SharedSuggestionProvider.suggest(ModSettings.VOID_PROPS, b);
    private static final SuggestionProvider<CommandSourceStack> DIALOGUE_PROPS =
            (c, b) -> SharedSuggestionProvider.suggest(ModSettings.DIALOGUE_PROPS, b);
    private static final SuggestionProvider<CommandSourceStack> ID_SUGGEST = (c, b) -> {
        List<String> l = new ArrayList<>();
        l.add("nearest");
        for (Integer id : DedData.get(c.getSource().getServer()).fields.keySet()) {
            l.add(String.valueOf(id));
        }
        return SharedSuggestionProvider.suggest(l, b);
    };

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("dedsafio")
                .requires(s -> s.hasPermission(2))
                .then(forcefield())
                .then(voidCmd())
                .then(dialogue())
                .then(permissions())
                .then(Commands.literal("status").executes(c -> status(c.getSource()))));
    }

    // =====================================================================  helpers

    private static void ok(CommandSourceStack s, String msg) {
        s.sendSuccess(() -> Component.literal(msg), true);
    }

    private static int fail(CommandSourceStack s, String msg) {
        s.sendFailure(Component.literal(msg));
        return 0;
    }

    private static DedData data(CommandSourceStack s) {
        return DedData.get(s.getServer());
    }

    private static <T extends ArgumentBuilder<CommandSourceStack, T>> T withParams(T base, Creator cr) {
        return base.executes(c -> cr.run(c, null, null, null))
                .then(Commands.argument("radius", FloatArgumentType.floatArg(1.0f, 256.0f))
                        .executes(c -> cr.run(c, FloatArgumentType.getFloat(c, "radius"), null, null))
                        .then(Commands.argument("resistance", FloatArgumentType.floatArg(1.0f))
                                .executes(c -> cr.run(c, FloatArgumentType.getFloat(c, "radius"),
                                        FloatArgumentType.getFloat(c, "resistance"), null))
                                .then(Commands.argument("seconds", IntegerArgumentType.integer(0))
                                        .executes(c -> cr.run(c, FloatArgumentType.getFloat(c, "radius"),
                                                FloatArgumentType.getFloat(c, "resistance"),
                                                IntegerArgumentType.getInteger(c, "seconds"))))));
    }

    /** Resuelve "nearest" o un id numerico. */
    private static ForceField resolve(CommandContext<CommandSourceStack> c, String token) {
        CommandSourceStack src = c.getSource();
        DedData d = data(src);
        if (token.equalsIgnoreCase("nearest")) {
            return ForceFieldManager.nearest(d, src.getLevel().dimension().location(), src.getPosition());
        }
        try {
            return d.fields.get(Integer.parseInt(token));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static void changed(CommandSourceStack s, ForceField f) {
        DedData d = data(s);
        d.setDirty();
        ForceFieldManager.markDirty(f.dimension);
    }

    // =====================================================================  forcefield

    private static LiteralArgumentBuilder<CommandSourceStack> forcefield() {
        Creator here = (c, r, res, sec) -> doCreate(c.getSource(), c.getSource().getPosition(), r, res, sec, null);
        Creator at = (c, r, res, sec) -> doCreate(c.getSource(), Vec3Argument.getVec3(c, "pos"), r, res, sec, null);
        Creator attach = (c, r, res, sec) -> {
            Entity e = EntityArgument.getEntity(c, "target");
            return doCreate(c.getSource(), e.position().add(0.0, e.getBbHeight() / 2.0, 0.0), r, res, sec, e);
        };

        return Commands.literal("forcefield")
                .then(Commands.literal("enable").executes(c -> {
                    data(c.getSource()).settings.ffEnabled = true;
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), "Campo de fuerza de Revil: ACTIVADO");
                    return 1;
                }))
                .then(Commands.literal("disable").executes(c -> {
                    data(c.getSource()).settings.ffEnabled = false;
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), "Campo de fuerza de Revil: DESACTIVADO (los campos existentes dejan de proteger)");
                    return 1;
                }))
                .then(withParams(Commands.literal("create"), here))
                .then(Commands.literal("create_at").then(withParams(Commands.argument("pos", Vec3Argument.vec3()), at)))
                .then(Commands.literal("attach").then(withParams(Commands.argument("target", EntityArgument.entity()), attach)))
                .then(Commands.literal("remove")
                        .then(Commands.literal("all").executes(c -> {
                            int n = ForceFieldManager.removeAll(c.getSource().getServer());
                            ok(c.getSource(), n + " campo(s) eliminado(s)");
                            return n;
                        }))
                        .then(Commands.argument("id", StringArgumentType.word()).suggests(ID_SUGGEST).executes(c -> {
                            ForceField f = resolve(c, StringArgumentType.getString(c, "id"));
                            if (f == null) return fail(c.getSource(), "No existe ese campo");
                            ForceFieldManager.remove(c.getSource().getServer(), f.id);
                            ok(c.getSource(), "Campo #" + f.id + " eliminado");
                            return 1;
                        })))
                .then(Commands.literal("list").executes(c -> list(c.getSource())))
                .then(Commands.literal("info").then(Commands.argument("id", StringArgumentType.word()).suggests(ID_SUGGEST)
                        .executes(c -> info(c, StringArgumentType.getString(c, "id")))))
                .then(Commands.literal("heal").then(Commands.argument("id", StringArgumentType.word()).suggests(ID_SUGGEST)
                        .executes(c -> {
                            ForceField f = resolve(c, StringArgumentType.getString(c, "id"));
                            if (f == null) return fail(c.getSource(), "No existe ese campo");
                            f.resistance = f.maxResistance;
                            changed(c.getSource(), f);
                            ok(c.getSource(), "Campo #" + f.id + " restaurado a " + f.maxResistance);
                            return 1;
                        })))
                .then(Commands.literal("set").then(Commands.argument("id", StringArgumentType.word()).suggests(ID_SUGGEST)
                        .then(Commands.argument("property", StringArgumentType.word()).suggests(FIELD_PROPS)
                                .then(Commands.argument("value", StringArgumentType.greedyString()).executes(c -> {
                                    ForceField f = resolve(c, StringArgumentType.getString(c, "id"));
                                    if (f == null) return fail(c.getSource(), "No existe ese campo");
                                    String err = f.set(StringArgumentType.getString(c, "property"), StringArgumentType.getString(c, "value"));
                                    if (err != null) return fail(c.getSource(), err);
                                    changed(c.getSource(), f);
                                    ok(c.getSource(), "Campo #" + f.id + ": " + StringArgumentType.getString(c, "property")
                                            + " = " + StringArgumentType.getString(c, "value"));
                                    return 1;
                                })))))
                .then(Commands.literal("member").then(Commands.argument("id", StringArgumentType.word()).suggests(ID_SUGGEST)
                        .then(Commands.literal("add").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                            ForceField f = resolve(c, StringArgumentType.getString(c, "id"));
                            if (f == null) return fail(c.getSource(), "No existe ese campo");
                            ServerPlayer p = EntityArgument.getPlayer(c, "player");
                            f.members.add(p.getUUID());
                            changed(c.getSource(), f);
                            ok(c.getSource(), p.getName().getString() + " es miembro del campo #" + f.id);
                            return 1;
                        })))
                        .then(Commands.literal("remove").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                            ForceField f = resolve(c, StringArgumentType.getString(c, "id"));
                            if (f == null) return fail(c.getSource(), "No existe ese campo");
                            ServerPlayer p = EntityArgument.getPlayer(c, "player");
                            f.members.remove(p.getUUID());
                            changed(c.getSource(), f);
                            ok(c.getSource(), p.getName().getString() + " ya no es miembro del campo #" + f.id);
                            return 1;
                        })))))
                .then(Commands.literal("defaults")
                        .executes(c -> {
                            FieldConfig fc = data(c.getSource()).settings.fieldDefaults;
                            ModSettings s = data(c.getSource()).settings;
                            ok(c.getSource(), "Defaults: " + describe(fc) + " | damage=" + s.damageMultiplier + " projectilecost="
                                    + s.projectileCost + " explosioncost=" + s.explosionCost + " maxfields=" + s.maxFieldsPerPlayer
                                    + " opendistance=" + s.doorOpenDistance);
                            return 1;
                        })
                        .then(Commands.argument("property", StringArgumentType.word()).suggests(FF_DEFAULT_PROPS)
                                .then(Commands.argument("value", StringArgumentType.greedyString()).executes(c -> {
                                    DedData d = data(c.getSource());
                                    String err = d.settings.setForceField(StringArgumentType.getString(c, "property"),
                                            StringArgumentType.getString(c, "value"));
                                    if (err != null) return fail(c.getSource(), err);
                                    d.setDirty();
                                    ok(c.getSource(), "Default " + StringArgumentType.getString(c, "property") + " = "
                                            + StringArgumentType.getString(c, "value"));
                                    return 1;
                                }))));
    }

    private static int doCreate(CommandSourceStack src, Vec3 pos, Float r, Float res, Integer sec, Entity follow) {
        DedData d = data(src);
        if (!d.settings.ffEnabled) {
            return fail(src, "La mecanica esta desactivada (/dedsafio forcefield enable)");
        }
        ServerLevel level = src.getLevel();
        java.util.UUID owner = src.getEntity() instanceof ServerPlayer p ? p.getUUID() : null;
        ForceField f = ForceFieldManager.create(src.getServer(), level, pos, r, res, sec, owner, follow);
        ok(src, "Campo #" + f.id + " creado: radio " + f.radius + ", resistencia " + f.maxResistance + ", duracion "
                + (f.durationSeconds <= 0 ? "infinita" : f.durationSeconds + "s") + (follow != null ? ", sigue a " + follow.getName().getString() : ""));
        return f.id;
    }

    private static String describe(FieldConfig f) {
        return "radius=" + f.radius + " resistance=" + f.maxResistance + " seconds=" + f.durationSeconds + " regen=" + f.regenPerSecond
                + " color=" + FieldConfig.hex(f.color1) + " color2=" + FieldConfig.hex(f.color2) + " opacity=" + f.opacity
                + " edge=" + f.edgeWidth + " pulse=" + f.pulse + " doorsize=" + f.doorSize + " doortime=" + f.doorTicks
                + " access=" + f.access + " mobs=" + f.blockMobs + " projectiles=" + f.blockProjectiles
                + " explosions=" + f.blockExplosions + " attacks=" + f.blockAttacks;
    }

    private static int list(CommandSourceStack src) {
        DedData d = data(src);
        if (d.fields.isEmpty()) {
            ok(src, "No hay campos activos");
            return 0;
        }
        for (ForceField f : d.fields.values()) {
            ok(src, String.format(Locale.ROOT, "#%d [%s] (%.1f, %.1f, %.1f) r=%.1f res=%.0f/%.0f resta=%s", f.id, f.dimension,
                    f.x, f.y, f.z, f.radius, f.resistance, f.maxResistance, f.ticksLeft < 0 ? "inf" : (f.ticksLeft / 20) + "s"));
        }
        return d.fields.size();
    }

    private static int info(CommandContext<CommandSourceStack> c, String token) {
        ForceField f = resolve(c, token);
        if (f == null) return fail(c.getSource(), "No existe ese campo");
        ok(c.getSource(), "Campo #" + f.id + " " + describe(f) + " resistencia=" + f.resistance + " miembros=" + f.members.size()
                + " puertas=" + f.doors.size());
        return 1;
    }

    // =====================================================================  void

    private static LiteralArgumentBuilder<CommandSourceStack> voidCmd() {
        return Commands.literal("void")
                .then(Commands.literal("enable").executes(c -> {
                    data(c.getSource()).settings.voEnabled = true;
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), "Espacio mental de Eon: ACTIVADO");
                    return 1;
                }))
                .then(Commands.literal("disable").executes(c -> {
                    data(c.getSource()).settings.voEnabled = false;
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), "Espacio mental de Eon: DESACTIVADO");
                    return 1;
                }))
                .then(Commands.literal("travel").executes(c -> travel(c.getSource(), List.of(c.getSource().getPlayerOrException())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(c -> travel(c.getSource(), EntityArgument.getPlayers(c, "targets")))))
                .then(Commands.literal("rebuild").executes(c -> {
                    if (!MindSpaceManager.rebuild(c.getSource().getServer())) {
                        return fail(c.getSource(), "La dimension dedsafio4:mind_space no esta cargada");
                    }
                    ok(c.getSource(), "Plataforma astral reconstruida");
                    return 1;
                }))
                .then(Commands.literal("set").then(Commands.argument("property", StringArgumentType.word()).suggests(VOID_PROPS)
                        .then(Commands.argument("value", StringArgumentType.greedyString()).executes(c -> {
                            DedData d = data(c.getSource());
                            String err = d.settings.setVoid(StringArgumentType.getString(c, "property"), StringArgumentType.getString(c, "value"));
                            if (err != null) return fail(c.getSource(), err);
                            d.setDirty();
                            ok(c.getSource(), "void " + StringArgumentType.getString(c, "property") + " = " + StringArgumentType.getString(c, "value"));
                            return 1;
                        }))))
                .then(Commands.literal("info").executes(c -> {
                    ModSettings s = data(c.getSource()).settings;
                    ok(c.getSource(), "void: enabled=" + s.voEnabled + " duration=" + (s.voDurationTicks / 20.0) + "s intensity=" + s.voIntensity
                            + " color=" + FieldConfig.hex(s.voColor) + " cooldown=" + s.voCooldownSec + "s height=" + s.voPlatformY);
                    return 1;
                }));
    }

    private static int travel(CommandSourceStack src, Collection<ServerPlayer> targets) {
        int n = 0;
        for (ServerPlayer p : targets) {
            if (MindSpaceManager.start(p, false)) {
                n++;
            }
        }
        ok(src, n + " jugador(es) inician el viaje dimensional");
        return n;
    }

    // =====================================================================  dialogue

    private static LiteralArgumentBuilder<CommandSourceStack> dialogue() {
        return Commands.literal("dialogue")
                .then(Commands.literal("enable").executes(c -> {
                    data(c.getSource()).settings.dlEnabled = true;
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), "Dialogos de Eon: ACTIVADOS");
                    return 1;
                }))
                .then(Commands.literal("disable").executes(c -> {
                    data(c.getSource()).settings.dlEnabled = false;
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), "Dialogos de Eon: DESACTIVADOS");
                    return 1;
                }))
                .then(Commands.literal("mode")
                        .then(Commands.literal("all").executes(c -> setMode(c.getSource(), false)))
                        .then(Commands.literal("list").executes(c -> setMode(c.getSource(), true))))
                .then(Commands.literal("add").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    ServerPlayer p = EntityArgument.getPlayer(c, "player");
                    data(c.getSource()).settings.dlList.add(p.getUUID());
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), p.getName().getString() + " anadido a la lista de dialogos");
                    return 1;
                })))
                .then(Commands.literal("remove").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    ServerPlayer p = EntityArgument.getPlayer(c, "player");
                    data(c.getSource()).settings.dlList.remove(p.getUUID());
                    data(c.getSource()).setDirty();
                    ok(c.getSource(), p.getName().getString() + " quitado de la lista de dialogos");
                    return 1;
                })))
                .then(Commands.literal("say").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("text", StringArgumentType.greedyString()).executes(c -> {
                            ServerPlayer p = EntityArgument.getPlayer(c, "player");
                            DialogueManager.show(p, StringArgumentType.getString(c, "text"), data(c.getSource()).settings);
                            return 1;
                        }))))
                .then(Commands.literal("set").then(Commands.argument("property", StringArgumentType.word()).suggests(DIALOGUE_PROPS)
                        .then(Commands.argument("value", StringArgumentType.greedyString()).executes(c -> {
                            DedData d = data(c.getSource());
                            String err = d.settings.setDialogue(StringArgumentType.getString(c, "property"), StringArgumentType.getString(c, "value"));
                            if (err != null) return fail(c.getSource(), err);
                            d.setDirty();
                            ok(c.getSource(), "dialogue " + StringArgumentType.getString(c, "property") + " = " + StringArgumentType.getString(c, "value"));
                            return 1;
                        }))))
                .then(Commands.literal("info").executes(c -> {
                    ModSettings s = data(c.getSource()).settings;
                    ok(c.getSource(), "dialogue: enabled=" + s.dlEnabled + " mode=" + (s.dlListMode ? "list(" + s.dlList.size() + ")" : "all")
                            + " duration=" + s.dlSeconds + "s scale=" + s.dlScale + " width=" + s.dlWidth + " height=" + s.dlHeight
                            + " color=" + FieldConfig.hex(s.dlBubbleColor) + " textcolor=" + FieldConfig.hex(s.dlTextColor));
                    return 1;
                }));
    }

    private static int setMode(CommandSourceStack src, boolean list) {
        data(src).settings.dlListMode = list;
        data(src).setDirty();
        ok(src, "Dialogos: modo " + (list ? "SOLO LISTA" : "TODOS LOS JUGADORES"));
        return 1;
    }

    // =====================================================================  permisos

    private static LiteralArgumentBuilder<CommandSourceStack> permissions() {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("permissions");
        for (Mechanic m : Mechanic.values()) {
            String name = m.name().toLowerCase(Locale.ROOT);
            root.then(Commands.literal(name)
                    .then(Commands.literal("level").then(Commands.argument("level", IntegerArgumentType.integer(0, 4)).executes(c -> {
                        DedData d = data(c.getSource());
                        d.settings.permLevel.put(m, IntegerArgumentType.getInteger(c, "level"));
                        d.setDirty();
                        ok(c.getSource(), "Permiso minimo de " + name + " = " + IntegerArgumentType.getInteger(c, "level"));
                        return 1;
                    })))
                    .then(Commands.literal("allow").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                        DedData d = data(c.getSource());
                        ServerPlayer p = EntityArgument.getPlayer(c, "player");
                        d.settings.allowed.get(m).add(p.getUUID());
                        d.setDirty();
                        ok(c.getSource(), p.getName().getString() + " puede usar " + name);
                        return 1;
                    })))
                    .then(Commands.literal("revoke").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                        DedData d = data(c.getSource());
                        ServerPlayer p = EntityArgument.getPlayer(c, "player");
                        d.settings.allowed.get(m).remove(p.getUUID());
                        d.setDirty();
                        ok(c.getSource(), p.getName().getString() + " ya no tiene acceso individual a " + name);
                        return 1;
                    }))));
        }
        return root;
    }

    private static int status(CommandSourceStack src) {
        DedData d = data(src);
        ModSettings s = d.settings;
        ok(src, "forcefield=" + s.ffEnabled + " (campos activos: " + d.fields.size() + ", permiso " + s.permLevel.get(Mechanic.FORCEFIELD)
                + ") | void=" + s.voEnabled + " (permiso " + s.permLevel.get(Mechanic.VOID) + ") | dialogue=" + s.dlEnabled
                + " (permiso " + s.permLevel.get(Mechanic.DIALOGUE) + ") | accesos: " + Arrays.toString(Access.values()));
        return 1;
    }
}
