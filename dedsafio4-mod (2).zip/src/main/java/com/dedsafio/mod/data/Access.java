package com.dedsafio.mod.data;

/** Quien puede abrir la puertita del campo de fuerza. */
public enum Access {
    /** Cualquier jugador. */
    ALL,
    /** Solo el dueno y los miembros del campo. */
    MEMBERS,
    /** Solo operadores (permiso 2+). */
    OPS,
    /** Nadie: el campo es totalmente cerrado. */
    NONE;

    public static Access parse(String s) {
        for (Access a : values()) {
            if (a.name().equalsIgnoreCase(s)) {
                return a;
            }
        }
        return null;
    }
}
