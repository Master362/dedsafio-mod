package com.dedsafio.mod.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Datos persistentes del mod guardados en el mundo (overworld): ajustes, campos activos y puntos de retorno. */
public class DedData extends SavedData {
    public static final String NAME = "dedsafio4";

    public ModSettings settings = new ModSettings();
    public final Map<Integer, ForceField> fields = new LinkedHashMap<>();
    public int nextId = 1;
    public boolean mindBuilt = false;
    public int mindBuiltY = 100;
    public final Map<UUID, ReturnPoint> returns = new HashMap<>();

    public static DedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(DedData::load, DedData::new, NAME);
    }

    /** Donde estaba el jugador antes de viajar al Espacio mental. */
    public static class ReturnPoint {
        public String dim;
        public double x, y, z;
        public float yRot, xRot;

        public ReturnPoint(String dim, double x, double y, double z, float yRot, float xRot) {
            this.dim = dim;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yRot = yRot;
            this.xRot = xRot;
        }
    }

    public static DedData load(CompoundTag tag) {
        DedData d = new DedData();
        d.settings = ModSettings.load(tag.getCompound("settings"));
        d.nextId = Math.max(1, tag.getInt("nextId"));
        d.mindBuilt = tag.getBoolean("mindBuilt");
        d.mindBuiltY = tag.getInt("mindBuiltY");
        for (Tag t : tag.getList("fields", Tag.TAG_COMPOUND)) {
            ForceField f = ForceField.load((CompoundTag) t);
            d.fields.put(f.id, f);
            d.nextId = Math.max(d.nextId, f.id + 1);
        }
        CompoundTag rets = tag.getCompound("returns");
        for (String k : rets.getAllKeys()) {
            try {
                CompoundTag r = rets.getCompound(k);
                d.returns.put(UUID.fromString(k), new ReturnPoint(r.getString("dim"),
                        r.getDouble("x"), r.getDouble("y"), r.getDouble("z"), r.getFloat("yRot"), r.getFloat("xRot")));
            } catch (IllegalArgumentException ignored) {
                // clave corrupta, se ignora
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.put("settings", settings.save());
        tag.putInt("nextId", nextId);
        tag.putBoolean("mindBuilt", mindBuilt);
        tag.putInt("mindBuiltY", mindBuiltY);
        ListTag fl = new ListTag();
        for (ForceField f : fields.values()) {
            fl.add(f.save());
        }
        tag.put("fields", fl);
        CompoundTag rets = new CompoundTag();
        for (Map.Entry<UUID, ReturnPoint> e : returns.entrySet()) {
            CompoundTag r = new CompoundTag();
            ReturnPoint p = e.getValue();
            r.putString("dim", p.dim);
            r.putDouble("x", p.x);
            r.putDouble("y", p.y);
            r.putDouble("z", p.z);
            r.putFloat("yRot", p.yRot);
            r.putFloat("xRot", p.xRot);
            rets.put(e.getKey().toString(), r);
        }
        tag.put("returns", rets);
        return tag;
    }
}
