package com.dedsafio.mod.data;

import net.minecraft.nbt.CompoundTag;

import java.util.List;
import java.util.Locale;

/**
 * Parametros configurables de un campo de fuerza. Sirve tanto como "valores por defecto" (ModSettings)
 * como base de cada campo concreto. Todo se puede cambiar con /dedsafio forcefield set|defaults.
 */
public class FieldConfig {
    public static final List<String> PROPERTIES = List.of(
            "radius", "resistance", "seconds", "regen", "color", "color2", "opacity", "edge", "pulse",
            "doorsize", "doortime", "access", "mobs", "projectiles", "explosions", "attacks");

    public float radius = 12.0f;
    public float maxResistance = 200.0f;
    /** 0 = infinito. */
    public int durationSeconds = 120;
    public float regenPerSecond = 0.0f;
    public int color1 = 0x8A2BE2;
    public int color2 = 0xFF2D6F;
    public float opacity = 0.35f;
    public float edgeWidth = 0.07f;
    public float pulse = 1.0f;
    /** Lado del cuadrado de la puerta en bloques. */
    public float doorSize = 3.0f;
    /** Ticks que la puerta permanece abierta tras la ultima senal. */
    public int doorTicks = 50;
    public Access access = Access.ALL;
    public boolean blockMobs = true;
    public boolean blockProjectiles = true;
    public boolean blockExplosions = true;
    public boolean blockAttacks = true;

    public void copyFrom(FieldConfig o) {
        radius = o.radius; maxResistance = o.maxResistance; durationSeconds = o.durationSeconds;
        regenPerSecond = o.regenPerSecond; color1 = o.color1; color2 = o.color2; opacity = o.opacity;
        edgeWidth = o.edgeWidth; pulse = o.pulse; doorSize = o.doorSize; doorTicks = o.doorTicks; access = o.access;
        blockMobs = o.blockMobs; blockProjectiles = o.blockProjectiles; blockExplosions = o.blockExplosions;
        blockAttacks = o.blockAttacks;
    }

    /** Aplica una propiedad por nombre. Devuelve null si todo fue bien o un mensaje de error. */
    public String set(String prop, String value) {
        String p = prop.toLowerCase(Locale.ROOT);
        String v = value.trim();
        try {
            switch (p) {
                case "radius" -> radius = clampF(parseF(v), 1.0f, 256.0f);
                case "resistance", "maxresistance" -> maxResistance = clampF(parseF(v), 1.0f, 1.0E7f);
                case "seconds", "duration" -> durationSeconds = Math.max(0, Integer.parseInt(v));
                case "regen" -> regenPerSecond = clampF(parseF(v), 0.0f, 1.0E6f);
                case "color" -> color1 = parseColor(v);
                case "color2" -> color2 = parseColor(v);
                case "opacity" -> opacity = clampF(parseF(v), 0.02f, 1.0f);
                case "edge" -> edgeWidth = clampF(parseF(v), 0.01f, 1.0f);
                case "pulse" -> pulse = clampF(parseF(v), 0.0f, 10.0f);
                case "doorsize" -> doorSize = clampF(parseF(v), 1.0f, 12.0f);
                case "doortime" -> doorTicks = Math.max(5, Math.min(1200, Integer.parseInt(v)));
                case "access" -> {
                    Access a = Access.parse(v);
                    if (a == null) {
                        return "Valores validos para access: ALL, MEMBERS, OPS, NONE";
                    }
                    access = a;
                }
                case "mobs" -> blockMobs = parseBool(v);
                case "projectiles" -> blockProjectiles = parseBool(v);
                case "explosions" -> blockExplosions = parseBool(v);
                case "attacks" -> blockAttacks = parseBool(v);
                default -> {
                    return "Propiedad desconocida: " + prop + ". Validas: " + String.join(", ", PROPERTIES);
                }
            }
        } catch (NumberFormatException ex) {
            return "Valor invalido para " + prop + ": " + value;
        }
        return null;
    }

    public static float parseF(String s) {
        return Float.parseFloat(s.replace(',', '.'));
    }

    public static boolean parseBool(String s) {
        String l = s.toLowerCase(Locale.ROOT);
        if (l.equals("true") || l.equals("on") || l.equals("si") || l.equals("yes") || l.equals("1")) {
            return true;
        }
        if (l.equals("false") || l.equals("off") || l.equals("no") || l.equals("0")) {
            return false;
        }
        throw new NumberFormatException(s);
    }

    /** Acepta "#RRGGBB", "RRGGBB" o "0xRRGGBB". */
    public static int parseColor(String s) {
        String h = s.trim();
        if (h.startsWith("#")) {
            h = h.substring(1);
        } else if (h.toLowerCase(Locale.ROOT).startsWith("0x")) {
            h = h.substring(2);
        }
        if (h.length() != 6) {
            throw new NumberFormatException(s);
        }
        return Integer.parseInt(h, 16) & 0xFFFFFF;
    }

    public static float clampF(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    public static String hex(int c) {
        return String.format("#%06X", c & 0xFFFFFF);
    }

    public void saveConfig(CompoundTag t) {
        t.putFloat("radius", radius); t.putFloat("maxRes", maxResistance); t.putInt("seconds", durationSeconds);
        t.putFloat("regen", regenPerSecond); t.putInt("c1", color1); t.putInt("c2", color2);
        t.putFloat("opacity", opacity); t.putFloat("edge", edgeWidth); t.putFloat("pulse", pulse);
        t.putFloat("doorSize", doorSize); t.putInt("doorTicks", doorTicks); t.putString("access", access.name());
        t.putBoolean("mobs", blockMobs); t.putBoolean("proj", blockProjectiles);
        t.putBoolean("expl", blockExplosions); t.putBoolean("atk", blockAttacks);
    }

    public void loadConfig(CompoundTag t) {
        if (t.contains("radius")) radius = t.getFloat("radius");
        if (t.contains("maxRes")) maxResistance = t.getFloat("maxRes");
        if (t.contains("seconds")) durationSeconds = t.getInt("seconds");
        if (t.contains("regen")) regenPerSecond = t.getFloat("regen");
        if (t.contains("c1")) color1 = t.getInt("c1");
        if (t.contains("c2")) color2 = t.getInt("c2");
        if (t.contains("opacity")) opacity = t.getFloat("opacity");
        if (t.contains("edge")) edgeWidth = t.getFloat("edge");
        if (t.contains("pulse")) pulse = t.getFloat("pulse");
        if (t.contains("doorSize")) doorSize = t.getFloat("doorSize");
        if (t.contains("doorTicks")) doorTicks = t.getInt("doorTicks");
        if (t.contains("access")) {
            Access a = Access.parse(t.getString("access"));
            if (a != null) access = a;
        }
        if (t.contains("mobs")) blockMobs = t.getBoolean("mobs");
        if (t.contains("proj")) blockProjectiles = t.getBoolean("proj");
        if (t.contains("expl")) blockExplosions = t.getBoolean("expl");
        if (t.contains("atk")) blockAttacks = t.getBoolean("atk");
    }
}
