package com.dedsafio.mod.data;

/** Puertita cuadrada abierta en un campo: direccion unitaria desde el centro + ticks de vida. */
public class FieldDoor {
    public double dx, dy, dz;
    public long openTick;
    public long expireTick;

    public FieldDoor(double dx, double dy, double dz, long openTick, long expireTick) {
        this.dx = dx;
        this.dy = dy;
        this.dz = dz;
        this.openTick = openTick;
        this.expireTick = expireTick;
    }
}
