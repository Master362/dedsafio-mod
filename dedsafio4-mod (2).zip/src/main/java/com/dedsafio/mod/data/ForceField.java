package com.dedsafio.mod.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Un campo de fuerza de Revil activo en el mundo (estado del servidor). */
public class ForceField extends FieldConfig {
    public int id;
    public ResourceLocation dimension;
    public double x, y, z;
    public float resistance = 200.0f;
    /** Ticks restantes; -1 = infinito. */
    public long ticksLeft = 2400L;
    public long totalTicks = 2400L;
    public UUID owner;
    public final Set<UUID> members = new HashSet<>();
    /** Si no es null, el campo sigue a esa entidad. */
    public UUID followUuid;

    // ---- estado transitorio (no se guarda)
    public int followEntityId = -1;
    public final List<FieldDoor> doors = new ArrayList<>();
    public final Map<Integer, Vec3> lastPos = new HashMap<>();
    public final Map<Integer, Long> lastWarn = new HashMap<>();
    public long lastHitSoundTick = -100L;

    public Vec3 center() {
        return new Vec3(x, y, z);
    }

    public boolean contains(Vec3 p) {
        double dx = p.x - x, dy = p.y - y, dz = p.z - z;
        return dx * dx + dy * dy + dz * dz < (double) radius * radius;
    }

    public void resetTimer() {
        ticksLeft = durationSeconds <= 0 ? -1L : durationSeconds * 20L;
        totalTicks = ticksLeft;
    }

    @Override
    public String set(String prop, String value) {
        String err = super.set(prop, value);
        if (err != null) {
            return err;
        }
        switch (prop.toLowerCase(java.util.Locale.ROOT)) {
            case "resistance", "maxresistance" -> resistance = maxResistance;
            case "seconds", "duration" -> resetTimer();
            default -> { }
        }
        return null;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        saveConfig(t);
        t.putInt("id", id);
        t.putString("dim", dimension.toString());
        t.putDouble("x", x); t.putDouble("y", y); t.putDouble("z", z);
        t.putFloat("res", resistance);
        t.putLong("left", ticksLeft); t.putLong("total", totalTicks);
        if (owner != null) t.putUUID("owner", owner);
        if (followUuid != null) t.putUUID("follow", followUuid);
        ListTag ml = new ListTag();
        for (UUID u : members) {
            ml.add(NbtUtils.createUUID(u));
        }
        t.put("members", ml);
        return t;
    }

    public static ForceField load(CompoundTag t) {
        ForceField f = new ForceField();
        f.loadConfig(t);
        f.id = t.getInt("id");
        f.dimension = new ResourceLocation(t.getString("dim"));
        f.x = t.getDouble("x"); f.y = t.getDouble("y"); f.z = t.getDouble("z");
        f.resistance = t.getFloat("res");
        f.ticksLeft = t.getLong("left"); f.totalTicks = t.getLong("total");
        if (t.hasUUID("owner")) f.owner = t.getUUID("owner");
        if (t.hasUUID("follow")) f.followUuid = t.getUUID("follow");
        for (Tag e : t.getList("members", Tag.TAG_INT_ARRAY)) {
            f.members.add(NbtUtils.loadUUID(e));
        }
        return f;
    }
}
