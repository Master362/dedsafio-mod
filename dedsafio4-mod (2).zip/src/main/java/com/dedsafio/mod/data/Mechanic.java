package com.dedsafio.mod.data;

/** Las tres mecanicas del mod (para permisos). */
public enum Mechanic {
    FORCEFIELD, VOID, DIALOGUE;

    public static Mechanic parse(String s) {
        for (Mechanic m : values()) {
            if (m.name().equalsIgnoreCase(s)) {
                return m;
            }
        }
        return null;
    }
}
