package com.dedsafio.mod.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Configuracion global editable por el staff con comandos. Se guarda dentro del mundo. */
public class ModSettings {
    // ---------------- Campo de Revil
    public final FieldConfig fieldDefaults = new FieldConfig();
    public boolean ffEnabled = true;
    public float damageMultiplier = 1.0f;
    public float projectileCost = 3.0f;
    public float explosionCost = 12.0f;
    public int maxFieldsPerPlayer = 1;
    /** Distancia a la pared a la que un jugador "pide" abrir la puertita. */
    public float doorOpenDistance = 3.0f;
    public static final List<String> FF_GLOBAL = List.of("damage", "projectilecost", "explosioncost", "maxfields", "opendistance");

    // ---------------- Espacio mental de Eon
    public boolean voEnabled = true;
    public int voDurationTicks = 100;
    public float voIntensity = 1.0f;
    public int voColor = 0xFFFFFF;
    public int voCooldownSec = 10;
    public int voPlatformY = 100;
    public static final List<String> VOID_PROPS = List.of("duration", "intensity", "color", "cooldown", "height");

    // ---------------- Dialogos de Eon
    public boolean dlEnabled = true;
    public boolean dlListMode = false;
    public final Set<UUID> dlList = new HashSet<>();
    public int dlSeconds = 6;
    public float dlScale = 1.0f;
    public int dlWidth = 120;
    public float dlHeight = 0.35f;
    public int dlBubbleColor = 0xFFFFFF;
    public int dlTextColor = 0x2A1B3D;
    public static final List<String> DIALOGUE_PROPS = List.of("duration", "scale", "width", "height", "color", "textcolor");

    // ---------------- Permisos
    public final Map<Mechanic, Integer> permLevel = new EnumMap<>(Mechanic.class);
    public final Map<Mechanic, Set<UUID>> allowed = new EnumMap<>(Mechanic.class);

    public ModSettings() {
        permLevel.put(Mechanic.FORCEFIELD, 2);
        permLevel.put(Mechanic.VOID, 2);
        permLevel.put(Mechanic.DIALOGUE, 0);
        for (Mechanic m : Mechanic.values()) {
            allowed.put(m, new HashSet<>());
        }
    }

    public String setForceField(String prop, String value) {
        String p = prop.toLowerCase(Locale.ROOT);
        try {
            switch (p) {
                case "damage" -> damageMultiplier = FieldConfig.clampF(FieldConfig.parseF(value), 0.0f, 100.0f);
                case "projectilecost" -> projectileCost = FieldConfig.clampF(FieldConfig.parseF(value), 0.0f, 10000.0f);
                case "explosioncost" -> explosionCost = FieldConfig.clampF(FieldConfig.parseF(value), 0.0f, 10000.0f);
                case "maxfields" -> maxFieldsPerPlayer = Math.max(1, Math.min(50, Integer.parseInt(value.trim())));
                case "opendistance" -> doorOpenDistance = FieldConfig.clampF(FieldConfig.parseF(value), 0.5f, 10.0f);
                default -> {
                    return fieldDefaults.set(prop, value);
                }
            }
        } catch (NumberFormatException e) {
            return "Valor invalido para " + prop + ": " + value;
        }
        return null;
    }

    public String setVoid(String prop, String value) {
        try {
            switch (prop.toLowerCase(Locale.ROOT)) {
                case "duration" -> voDurationTicks = Math.round(FieldConfig.clampF(FieldConfig.parseF(value), 2.0f, 30.0f) * 20.0f);
                case "intensity" -> voIntensity = FieldConfig.clampF(FieldConfig.parseF(value), 0.2f, 5.0f);
                case "color" -> voColor = FieldConfig.parseColor(value);
                case "cooldown" -> voCooldownSec = Math.max(0, Math.min(3600, Integer.parseInt(value.trim())));
                case "height" -> voPlatformY = Math.max(10, Math.min(240, Integer.parseInt(value.trim())));
                default -> {
                    return "Propiedad desconocida: " + prop + ". Validas: " + String.join(", ", VOID_PROPS);
                }
            }
        } catch (NumberFormatException e) {
            return "Valor invalido para " + prop + ": " + value;
        }
        return null;
    }

    public String setDialogue(String prop, String value) {
        try {
            switch (prop.toLowerCase(Locale.ROOT)) {
                case "duration" -> dlSeconds = Math.max(1, Math.min(60, Integer.parseInt(value.trim())));
                case "scale" -> dlScale = FieldConfig.clampF(FieldConfig.parseF(value), 0.4f, 3.0f);
                case "width" -> dlWidth = Math.max(60, Math.min(300, Integer.parseInt(value.trim())));
                case "height" -> dlHeight = FieldConfig.clampF(FieldConfig.parseF(value), -1.0f, 4.0f);
                case "color" -> dlBubbleColor = FieldConfig.parseColor(value);
                case "textcolor" -> dlTextColor = FieldConfig.parseColor(value);
                default -> {
                    return "Propiedad desconocida: " + prop + ". Validas: " + String.join(", ", DIALOGUE_PROPS);
                }
            }
        } catch (NumberFormatException e) {
            return "Valor invalido para " + prop + ": " + value;
        }
        return null;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        CompoundTag fd = new CompoundTag();
        fieldDefaults.saveConfig(fd);
        t.put("fieldDefaults", fd);
        t.putBoolean("ffEnabled", ffEnabled);
        t.putFloat("damageMult", damageMultiplier);
        t.putFloat("projCost", projectileCost);
        t.putFloat("explCost", explosionCost);
        t.putInt("maxFields", maxFieldsPerPlayer);
        t.putFloat("openDist", doorOpenDistance);
        t.putBoolean("voEnabled", voEnabled);
        t.putInt("voDur", voDurationTicks);
        t.putFloat("voInt", voIntensity);
        t.putInt("voColor", voColor);
        t.putInt("voCd", voCooldownSec);
        t.putInt("voY", voPlatformY);
        t.putBoolean("dlEnabled", dlEnabled);
        t.putBoolean("dlList", dlListMode);
        t.putInt("dlSec", dlSeconds);
        t.putFloat("dlScale", dlScale);
        t.putInt("dlWidth", dlWidth);
        t.putFloat("dlHeight", dlHeight);
        t.putInt("dlBubble", dlBubbleColor);
        t.putInt("dlText", dlTextColor);
        t.put("dlPlayers", uuidList(dlList));
        CompoundTag perms = new CompoundTag();
        for (Mechanic m : Mechanic.values()) {
            CompoundTag mt = new CompoundTag();
            mt.putInt("level", permLevel.get(m));
            mt.put("allowed", uuidList(allowed.get(m)));
            perms.put(m.name(), mt);
        }
        t.put("perms", perms);
        return t;
    }

    public static ModSettings load(CompoundTag t) {
        ModSettings s = new ModSettings();
        if (t.contains("fieldDefaults")) s.fieldDefaults.loadConfig(t.getCompound("fieldDefaults"));
        if (t.contains("ffEnabled")) s.ffEnabled = t.getBoolean("ffEnabled");
        if (t.contains("damageMult")) s.damageMultiplier = t.getFloat("damageMult");
        if (t.contains("projCost")) s.projectileCost = t.getFloat("projCost");
        if (t.contains("explCost")) s.explosionCost = t.getFloat("explCost");
        if (t.contains("maxFields")) s.maxFieldsPerPlayer = t.getInt("maxFields");
        if (t.contains("openDist")) s.doorOpenDistance = t.getFloat("openDist");
        if (t.contains("voEnabled")) s.voEnabled = t.getBoolean("voEnabled");
        if (t.contains("voDur")) s.voDurationTicks = t.getInt("voDur");
        if (t.contains("voInt")) s.voIntensity = t.getFloat("voInt");
        if (t.contains("voColor")) s.voColor = t.getInt("voColor");
        if (t.contains("voCd")) s.voCooldownSec = t.getInt("voCd");
        if (t.contains("voY")) s.voPlatformY = t.getInt("voY");
        if (t.contains("dlEnabled")) s.dlEnabled = t.getBoolean("dlEnabled");
        if (t.contains("dlList")) s.dlListMode = t.getBoolean("dlList");
        if (t.contains("dlSec")) s.dlSeconds = t.getInt("dlSec");
        if (t.contains("dlScale")) s.dlScale = t.getFloat("dlScale");
        if (t.contains("dlWidth")) s.dlWidth = t.getInt("dlWidth");
        if (t.contains("dlHeight")) s.dlHeight = t.getFloat("dlHeight");
        if (t.contains("dlBubble")) s.dlBubbleColor = t.getInt("dlBubble");
        if (t.contains("dlText")) s.dlTextColor = t.getInt("dlText");
        readUuids(t.getList("dlPlayers", Tag.TAG_INT_ARRAY), s.dlList);
        CompoundTag perms = t.getCompound("perms");
        for (Mechanic m : Mechanic.values()) {
            if (perms.contains(m.name())) {
                CompoundTag mt = perms.getCompound(m.name());
                s.permLevel.put(m, mt.getInt("level"));
                readUuids(mt.getList("allowed", Tag.TAG_INT_ARRAY), s.allowed.get(m));
            }
        }
        return s;
    }

    private static ListTag uuidList(Set<UUID> set) {
        ListTag l = new ListTag();
        for (UUID u : set) {
            l.add(NbtUtils.createUUID(u));
        }
        return l;
    }

    private static void readUuids(ListTag l, Set<UUID> out) {
        for (Tag e : l) {
            out.add(NbtUtils.loadUUID(e));
        }
    }
}
