package com.dedsafio.mod.net;

import com.dedsafio.mod.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: mostrar una nube de dialogo sobre la cabeza de una entidad. */
public class DialoguePacket {
    public final int entityId;
    public final String text;
    public final int durationTicks;
    public final int bubbleColor;
    public final int textColor;
    public final float scale;
    public final float yOffset;
    public final int maxWidth;

    public DialoguePacket(int entityId, String text, int durationTicks, int bubbleColor, int textColor,
                          float scale, float yOffset, int maxWidth) {
        this.entityId = entityId;
        this.text = text;
        this.durationTicks = durationTicks;
        this.bubbleColor = bubbleColor;
        this.textColor = textColor;
        this.scale = scale;
        this.yOffset = yOffset;
        this.maxWidth = maxWidth;
    }

    public static void encode(DialoguePacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.entityId);
        buf.writeUtf(p.text, 300);
        buf.writeVarInt(p.durationTicks);
        buf.writeInt(p.bubbleColor);
        buf.writeInt(p.textColor);
        buf.writeFloat(p.scale);
        buf.writeFloat(p.yOffset);
        buf.writeVarInt(p.maxWidth);
    }

    public static DialoguePacket decode(FriendlyByteBuf buf) {
        return new DialoguePacket(buf.readVarInt(), buf.readUtf(300), buf.readVarInt(), buf.readInt(), buf.readInt(),
                buf.readFloat(), buf.readFloat(), buf.readVarInt());
    }

    public static void handle(DialoguePacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onDialogue(p)));
        ctx.get().setPacketHandled(true);
    }
}
