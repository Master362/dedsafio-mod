package com.dedsafio.mod.net;

import com.dedsafio.mod.client.ClientPacketHandler;
import com.dedsafio.mod.data.FieldDoor;
import com.dedsafio.mod.data.ForceField;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Supplier;

/** Servidor -> cliente: lista completa de campos (con sus puertas) de una dimension. */
public class FieldSyncPacket {
    public static class DoorEntry {
        public float dx, dy, dz;
        public long open, expire;
    }

    public static class Entry {
        public int id;
        public double x, y, z;
        public float radius, resistance, maxResistance;
        public long endTick;
        public int color1, color2;
        public float opacity, edge, pulse, doorSize;
        public int followId;
        public final List<DoorEntry> doors = new ArrayList<>();
    }

    public ResourceLocation dimension;
    public long serverTime;
    public final List<Entry> entries = new ArrayList<>();

    public static FieldSyncPacket from(ServerLevel level, Collection<ForceField> fields) {
        FieldSyncPacket p = new FieldSyncPacket();
        p.dimension = level.dimension().location();
        p.serverTime = level.getGameTime();
        for (ForceField f : fields) {
            Entry e = new Entry();
            e.id = f.id;
            e.x = f.x; e.y = f.y; e.z = f.z;
            e.radius = f.radius; e.resistance = f.resistance; e.maxResistance = f.maxResistance;
            e.endTick = f.ticksLeft < 0 ? -1L : p.serverTime + f.ticksLeft;
            e.color1 = f.color1; e.color2 = f.color2;
            e.opacity = f.opacity; e.edge = f.edgeWidth; e.pulse = f.pulse; e.doorSize = f.doorSize;
            e.followId = f.followEntityId;
            for (FieldDoor d : f.doors) {
                DoorEntry de = new DoorEntry();
                de.dx = (float) d.dx; de.dy = (float) d.dy; de.dz = (float) d.dz;
                de.open = d.openTick; de.expire = d.expireTick;
                e.doors.add(de);
            }
            p.entries.add(e);
        }
        return p;
    }

    public static void encode(FieldSyncPacket p, FriendlyByteBuf buf) {
        buf.writeResourceLocation(p.dimension);
        buf.writeLong(p.serverTime);
        buf.writeVarInt(p.entries.size());
        for (Entry e : p.entries) {
            buf.writeVarInt(e.id);
            buf.writeDouble(e.x); buf.writeDouble(e.y); buf.writeDouble(e.z);
            buf.writeFloat(e.radius); buf.writeFloat(e.resistance); buf.writeFloat(e.maxResistance);
            buf.writeLong(e.endTick);
            buf.writeInt(e.color1); buf.writeInt(e.color2);
            buf.writeFloat(e.opacity); buf.writeFloat(e.edge); buf.writeFloat(e.pulse); buf.writeFloat(e.doorSize);
            buf.writeInt(e.followId);
            buf.writeVarInt(e.doors.size());
            for (DoorEntry d : e.doors) {
                buf.writeFloat(d.dx); buf.writeFloat(d.dy); buf.writeFloat(d.dz);
                buf.writeLong(d.open); buf.writeLong(d.expire);
            }
        }
    }

    public static FieldSyncPacket decode(FriendlyByteBuf buf) {
        FieldSyncPacket p = new FieldSyncPacket();
        p.dimension = buf.readResourceLocation();
        p.serverTime = buf.readLong();
        int n = buf.readVarInt();
        for (int i = 0; i < n; i++) {
            Entry e = new Entry();
            e.id = buf.readVarInt();
            e.x = buf.readDouble(); e.y = buf.readDouble(); e.z = buf.readDouble();
            e.radius = buf.readFloat(); e.resistance = buf.readFloat(); e.maxResistance = buf.readFloat();
            e.endTick = buf.readLong();
            e.color1 = buf.readInt(); e.color2 = buf.readInt();
            e.opacity = buf.readFloat(); e.edge = buf.readFloat(); e.pulse = buf.readFloat(); e.doorSize = buf.readFloat();
            e.followId = buf.readInt();
            int dn = buf.readVarInt();
            for (int k = 0; k < dn; k++) {
                DoorEntry d = new DoorEntry();
                d.dx = buf.readFloat(); d.dy = buf.readFloat(); d.dz = buf.readFloat();
                d.open = buf.readLong(); d.expire = buf.readLong();
                e.doors.add(d);
            }
            p.entries.add(e);
        }
        return p;
    }

    public static void handle(FieldSyncPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onFieldSync(p)));
        ctx.get().setPacketHandled(true);
    }
}
