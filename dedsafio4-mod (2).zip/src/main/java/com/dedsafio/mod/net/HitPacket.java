package com.dedsafio.mod.net;

import com.dedsafio.mod.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: un golpe impacto el campo (ondulacion, chispas, sonido) o el campo se rompio. */
public class HitPacket {
    public final int fieldId;
    public final float dx, dy, dz;
    public final boolean broken;
    public final float strength;

    public HitPacket(int fieldId, float dx, float dy, float dz, boolean broken, float strength) {
        this.fieldId = fieldId;
        this.dx = dx;
        this.dy = dy;
        this.dz = dz;
        this.broken = broken;
        this.strength = strength;
    }

    public static void encode(HitPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.fieldId);
        buf.writeFloat(p.dx); buf.writeFloat(p.dy); buf.writeFloat(p.dz);
        buf.writeBoolean(p.broken);
        buf.writeFloat(p.strength);
    }

    public static HitPacket decode(FriendlyByteBuf buf) {
        return new HitPacket(buf.readVarInt(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readBoolean(), buf.readFloat());
    }

    public static void handle(HitPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onHit(p)));
        ctx.get().setPacketHandled(true);
    }
}
