package com.dedsafio.mod.net;

import com.dedsafio.mod.DedsafioMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(DedsafioMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static boolean registered = false;

    public static synchronized void register() {
        if (registered) {
            return;
        }
        registered = true;
        int id = 0;
        CHANNEL.registerMessage(id++, FieldSyncPacket.class, FieldSyncPacket::encode, FieldSyncPacket::decode, FieldSyncPacket::handle);
        CHANNEL.registerMessage(id++, HitPacket.class, HitPacket::encode, HitPacket::decode, HitPacket::handle);
        CHANNEL.registerMessage(id++, DialoguePacket.class, DialoguePacket::encode, DialoguePacket::decode, DialoguePacket::handle);
        CHANNEL.registerMessage(id++, WarpPacket.class, WarpPacket::encode, WarpPacket::decode, WarpPacket::handle);
    }

    private ModNetwork() {}
}
