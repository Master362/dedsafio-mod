package com.dedsafio.mod.net;

import com.dedsafio.mod.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: iniciar la transicion de vacio negro con destellos (viaje dimensional). */
public class WarpPacket {
    public final int durationTicks;
    public final float intensity;
    public final int color;

    public WarpPacket(int durationTicks, float intensity, int color) {
        this.durationTicks = durationTicks;
        this.intensity = intensity;
        this.color = color;
    }

    public static void encode(WarpPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.durationTicks);
        buf.writeFloat(p.intensity);
        buf.writeInt(p.color);
    }

    public static WarpPacket decode(FriendlyByteBuf buf) {
        return new WarpPacket(buf.readVarInt(), buf.readFloat(), buf.readInt());
    }

    public static void handle(WarpPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onWarp(p)));
        ctx.get().setPacketHandled(true);
    }
}
