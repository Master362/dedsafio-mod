package com.dedsafio.mod.registry;

import com.dedsafio.mod.DedsafioMod;
import com.dedsafio.mod.item.EonOrbItem;
import com.dedsafio.mod.item.RevilCoreItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DedsafioMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DedsafioMod.MODID);

    public static final RegistryObject<Item> REVIL_CORE =
            ITEMS.register("revil_core", () -> new RevilCoreItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> EON_ORB =
            ITEMS.register("eon_orb", () -> new EonOrbItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + DedsafioMod.MODID))
            .icon(() -> new ItemStack(REVIL_CORE.get()))
            .displayItems((params, output) -> {
                output.accept(REVIL_CORE.get());
                output.accept(EON_ORB.get());
            })
            .build());

    private ModItems() {}
}
