package com.dedsafio.mod.registry;

import com.dedsafio.mod.DedsafioMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DedsafioMod.MODID);

    public static final RegistryObject<SoundEvent> FIELD_ACTIVATE = reg("field_activate");
    public static final RegistryObject<SoundEvent> FIELD_HIT = reg("field_hit");
    public static final RegistryObject<SoundEvent> FIELD_BREAK = reg("field_break");
    public static final RegistryObject<SoundEvent> DOOR_OPEN = reg("door_open");
    public static final RegistryObject<SoundEvent> WARP = reg("warp");
    public static final RegistryObject<SoundEvent> BUBBLE = reg("bubble");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(DedsafioMod.MODID, name)));
    }

    private ModSounds() {}
}
