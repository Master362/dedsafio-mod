package com.dedsafio.mod.server;

import com.dedsafio.mod.data.DedData;
import com.dedsafio.mod.data.Mechanic;
import com.dedsafio.mod.data.ModSettings;
import com.dedsafio.mod.net.DialoguePacket;
import com.dedsafio.mod.net.ModNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

/** Dialogos de Eon: lo que se escribe en el chat aparece como una nube sobre la cabeza del jugador. */
public final class DialogueManager {
    private DialogueManager() {}

    /** Se llama al enviar un mensaje de chat. */
    public static void onChat(ServerPlayer player, String raw) {
        ModSettings s = DedData.get(player.server).settings;
        if (!s.dlEnabled || !Perms.can(player, Mechanic.DIALOGUE)) {
            return;
        }
        if (s.dlListMode && !s.dlList.contains(player.getUUID())) {
            return;
        }
        show(player, raw, s);
    }

    /** Muestra una nube con un texto concreto (tambien lo usa /dedsafio dialogue say). */
    public static void show(ServerPlayer player, String raw, ModSettings s) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) {
            return;
        }
        if (text.length() > 140) {
            text = text.substring(0, 139) + "…";
        }
        DialoguePacket pkt = new DialoguePacket(player.getId(), text, s.dlSeconds * 20, s.dlBubbleColor, s.dlTextColor,
                s.dlScale, s.dlHeight, s.dlWidth);
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), pkt);
    }
}
