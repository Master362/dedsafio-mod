package com.dedsafio.mod.server;

import com.dedsafio.mod.data.DedData;
import com.dedsafio.mod.data.FieldDoor;
import com.dedsafio.mod.data.ForceField;
import com.dedsafio.mod.data.Mechanic;
import com.dedsafio.mod.data.ModSettings;
import com.dedsafio.mod.net.FieldSyncPacket;
import com.dedsafio.mod.net.HitPacket;
import com.dedsafio.mod.net.ModNetwork;
import com.dedsafio.mod.registry.ModSounds;
import com.dedsafio.mod.util.DoorMath;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Logica del servidor del Campo de fuerza de Revil:
 *  - esfera que envuelve una zona o sigue a una entidad
 *  - bloquea ataques, proyectiles, explosiones y mobs
 *  - los JUGADORES permitidos abren una puertita cuadrada al acercarse a la pared para salir/entrar
 */
public final class ForceFieldManager {
    private static final Set<ResourceLocation> DIRTY = new HashSet<>();
    private static int syncCounter = 0;

    private ForceFieldManager() {}

    public static ResourceKey<Level> dimKey(ResourceLocation id) {
        return ResourceKey.create(Registries.DIMENSION, id);
    }

    public static void markDirty(ResourceLocation dim) {
        DIRTY.add(dim);
    }

    public static void clearStatics() {
        DIRTY.clear();
        syncCounter = 0;
    }

    // ------------------------------------------------------------------ creacion / borrado

    public static ForceField create(MinecraftServer server, ServerLevel level, Vec3 pos, Float radius,
                                    Float resistance, Integer seconds, UUID owner,
                                    Entity follow) {
        DedData d = DedData.get(server);
        ModSettings s = d.settings;
        if (owner != null) {
            // limite de campos por jugador: se elimina el mas antiguo
            List<ForceField> owned = new ArrayList<>();
            for (ForceField o : d.fields.values()) {
                if (owner.equals(o.owner)) {
                    owned.add(o);
                }
            }
            while (owned.size() >= s.maxFieldsPerPlayer) {
                ForceField oldest = owned.remove(0);
                remove(server, oldest.id);
            }
        }
        ForceField f = new ForceField();
        f.copyFrom(s.fieldDefaults);
        if (radius != null) f.radius = radius;
        if (resistance != null) f.maxResistance = resistance;
        if (seconds != null) f.durationSeconds = seconds;
        f.resistance = f.maxResistance;
        f.resetTimer();
        f.id = d.nextId++;
        f.dimension = level.dimension().location();
        f.x = pos.x; f.y = pos.y; f.z = pos.z;
        f.owner = owner;
        if (follow != null) {
            f.followUuid = follow.getUUID();
            f.followEntityId = follow.getId();
        }
        d.fields.put(f.id, f);
        d.setDirty();
        markDirty(f.dimension);
        level.playSound(null, pos.x, pos.y, pos.z, ModSounds.FIELD_ACTIVATE.get(), SoundSource.PLAYERS, 3.0f, 1.0f);
        return f;
    }

    public static boolean remove(MinecraftServer server, int id) {
        DedData d = DedData.get(server);
        ForceField f = d.fields.remove(id);
        if (f == null) {
            return false;
        }
        d.setDirty();
        markDirty(f.dimension);
        return true;
    }

    public static int removeAll(MinecraftServer server) {
        DedData d = DedData.get(server);
        int n = d.fields.size();
        for (ForceField f : d.fields.values()) {
            markDirty(f.dimension);
        }
        d.fields.clear();
        d.setDirty();
        return n;
    }

    public static List<ForceField> fieldsIn(DedData d, ResourceLocation dim) {
        List<ForceField> out = new ArrayList<>();
        for (ForceField f : d.fields.values()) {
            if (f.dimension.equals(dim)) {
                out.add(f);
            }
        }
        return out;
    }

    /** Campo mas cercano (por distancia al centro) en la dimension del punto, o null. */

    public static ForceField nearest(DedData d, ResourceLocation dim, Vec3 pos) {
        ForceField best = null;
        double bestD = Double.MAX_VALUE;
        for (ForceField f : d.fields.values()) {
            if (!f.dimension.equals(dim)) {
                continue;
            }
            double dist = f.center().distanceToSqr(pos);
            if (dist < bestD) {
                bestD = dist;
                best = f;
            }
        }
        return best;
    }

    /** Uso del item "Nucleo de Revil". */
    public static void useItem(ServerPlayer p) {
        DedData d = DedData.get(p.server);
        ModSettings s = d.settings;
        if (!s.ffEnabled) {
            p.displayClientMessage(Component.translatable("msg.dedsafio4.mechanic_disabled"), true);
            return;
        }
        if (!Perms.can(p, Mechanic.FORCEFIELD)) {
            p.displayClientMessage(Component.translatable("msg.dedsafio4.no_permission"), true);
            return;
        }
        ServerLevel level = p.serverLevel();
        if (p.isShiftKeyDown()) {
            ForceField best = null;
            double bd = Double.MAX_VALUE;
            for (ForceField f : d.fields.values()) {
                if (f.dimension.equals(level.dimension().location()) && p.getUUID().equals(f.owner)) {
                    double dd = f.center().distanceToSqr(p.position());
                    if (dd < bd) {
                        bd = dd;
                        best = f;
                    }
                }
            }
            if (best != null) {
                remove(p.server, best.id);
                p.displayClientMessage(Component.literal("Campo #" + best.id + " eliminado"), true);
            }
            return;
        }
        ForceField f = create(p.server, level, p.position(), null, null, null, p.getUUID(), null);
        p.displayClientMessage(Component.literal("Campo #" + f.id + " activado"), true);
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer server) {
        DedData d = DedData.get(server);
        if (!d.fields.isEmpty()) {
            Iterator<ForceField> it = d.fields.values().iterator();
            boolean changed = false;
            while (it.hasNext()) {
                ForceField f = it.next();
                ServerLevel level = server.getLevel(dimKey(f.dimension));
                if (level == null) {
                    continue;
                }
                if (tickField(server, level, d, f)) {
                    it.remove();
                    markDirty(f.dimension);
                    changed = true;
                }
            }
            if (changed) {
                d.setDirty();
            }
        }
        flushSync(server, d);
    }

    /** @return true si el campo debe eliminarse. */
    private static boolean tickField(MinecraftServer server, ServerLevel level, DedData d, ForceField f) {
        ModSettings s = d.settings;
        long now = level.getGameTime();

        if (f.followUuid != null) {
            Entity target = level.getEntity(f.followUuid);
            if (target != null && target.isAlive()) {
                f.x = target.getX();
                f.y = target.getY() + target.getBbHeight() / 2.0;
                f.z = target.getZ();
                if (f.followEntityId != target.getId()) {
                    f.followEntityId = target.getId();
                    markDirty(f.dimension);
                }
            } else if (target != null) {
                broadcastHit(level, f, new Vec3(0, 1, 0), true, -1.0f);
                return true;
            }
        }

        if (f.resistance <= 0.0f) {
            return true;
        }
        if (f.ticksLeft > 0 && --f.ticksLeft == 0) {
            broadcastHit(level, f, new Vec3(0, 1, 0), true, -1.0f);
            return true;
        }
        if (f.regenPerSecond > 0.0f && f.resistance < f.maxResistance && now % 20L == 0L) {
            f.resistance = Math.min(f.maxResistance, f.resistance + f.regenPerSecond);
            markDirty(f.dimension);
        }
        if (f.doors.removeIf(dr -> dr.expireTick <= now)) {
            markDirty(f.dimension);
        }

        double r = f.radius;
        AABB box = new AABB(f.x - r - 8.0, f.y - r - 8.0, f.z - r - 8.0, f.x + r + 8.0, f.y + r + 8.0, f.z + r + 8.0);
        List<Entity> list = level.getEntitiesOfClass(Entity.class, box,
                e -> e instanceof LivingEntity || e instanceof Projectile);
        Set<Integer> seen = new HashSet<>();
        Vec3 center = f.center();
        for (Entity e : list) {
            if (e.isSpectator()) {
                continue;
            }
            int eid = e.getId();
            seen.add(eid);
            Vec3 cur = e.position().add(0.0, e.getBbHeight() / 2.0, 0.0);
            Vec3 prev = f.lastPos.put(eid, cur);
            if (prev == null) {
                continue;
            }
            boolean wasIn = f.contains(prev);
            boolean isIn = f.contains(cur);
            if (e instanceof ServerPlayer p) {
                handlePlayer(level, d, f, p, center, prev, cur, wasIn, isIn, now);
            } else if (e instanceof Projectile pr) {
                if (!wasIn && isIn && f.blockProjectiles) {
                    pr.discard();
                    absorb(level, d, f, s.projectileCost, cur);
                }
            } else if (e instanceof LivingEntity le && f.blockMobs && wasIn != isIn) {
                handleMob(f, le, center, prev, cur, isIn);
            }
        }
        f.lastPos.keySet().retainAll(seen);
        f.lastWarn.keySet().retainAll(seen);
        return false;
    }

    private static boolean doorAllowed(ForceField f, ServerPlayer p) {
        return switch (f.access) {
            case ALL -> true;
            case MEMBERS -> p.getUUID().equals(f.owner) || f.members.contains(p.getUUID());
            case OPS -> p.hasPermissions(2);
            case NONE -> false;
        };
    }

    private static boolean inAnyDoor(ForceField f, Vec3 rel, long now) {
        double half = f.doorSize / 2.0 + 0.35;
        for (FieldDoor dr : f.doors) {
            if (dr.expireTick > now && DoorMath.inside(dr.dx, dr.dy, dr.dz, rel.x, rel.y, rel.z, half)) {
                return true;
            }
        }
        return false;
    }

    private static void handlePlayer(ServerLevel level, DedData d, ForceField f, ServerPlayer p, Vec3 center,
                                     Vec3 prev, Vec3 cur, boolean wasIn, boolean isIn, long now) {
        boolean allowed = doorAllowed(f, p);
        double dist = cur.distanceTo(center);

        // 1) Un jugador permitido que se acerca a la pared "pide" la puertita cuadrada
        if (allowed && Math.abs(dist - f.radius) < d.settings.doorOpenDistance && dist > 1.0E-3) {
            Vec3 radial = cur.subtract(center).scale(1.0 / dist);
            double vRad = cur.subtract(prev).dot(radial);
            boolean towards = dist < f.radius ? vRad > 0.015 : vRad < -0.015;
            if (towards || Math.abs(dist - f.radius) < 1.3) {
                requestDoor(level, f, radial, now);
            }
        }

        // 2) Cruce de la pared
        if (wasIn == isIn) {
            return;
        }
        if (allowed && (inAnyDoor(f, prev.subtract(center), now) || inAnyDoor(f, cur.subtract(center), now))) {
            return;
        }
        Vec3 delta = prev.subtract(cur);
        Entity mover = p.isPassenger() ? p.getRootVehicle() : p;
        Vec3 push = (wasIn ? center.subtract(cur) : cur.subtract(center));
        push = push.lengthSqr() > 1.0E-6 ? push.normalize().scale(0.3) : Vec3.ZERO;
        if (mover == p) {
            p.connection.teleport(p.getX() + delta.x, p.getY() + delta.y, p.getZ() + delta.z, p.getYRot(), p.getXRot());
            p.setDeltaMovement(push.x, 0.05, push.z);
            p.hurtMarked = true;
        } else {
            mover.setPos(mover.getX() + delta.x, mover.getY() + delta.y, mover.getZ() + delta.z);
            mover.setDeltaMovement(Vec3.ZERO);
        }
        f.lastPos.put(p.getId(), prev);
        Long last = f.lastWarn.get(p.getId());
        if (last == null || now - last > 30L) {
            f.lastWarn.put(p.getId(), now);
            p.displayClientMessage(Component.translatable("msg.dedsafio4.field_blocked"), true);
            broadcastHit(level, f, cur.subtract(center), false, 0.25f);
        }
    }

    private static void handleMob(ForceField f, LivingEntity le, Vec3 center, Vec3 prev, Vec3 cur, boolean isIn) {
        // una montura que lleva a un jugador permitido puede usar las puertas
        for (Entity passenger : le.getPassengers()) {
            if (passenger instanceof ServerPlayer sp && doorAllowed(f, sp)) {
                long now = le.level().getGameTime();
                if (inAnyDoor(f, prev.subtract(center), now) || inAnyDoor(f, cur.subtract(center), now)) {
                    return;
                }
            }
        }
        Vec3 delta = prev.subtract(cur);
        le.setPos(le.getX() + delta.x, le.getY() + delta.y, le.getZ() + delta.z);
        Vec3 push = isIn ? cur.subtract(center) : center.subtract(cur);
        push = push.lengthSqr() > 1.0E-6 ? push.normalize().scale(0.2) : Vec3.ZERO;
        le.setDeltaMovement(push.x, le.getDeltaMovement().y, push.z);
        le.hurtMarked = true;
        f.lastPos.put(le.getId(), prev);
    }

    private static void requestDoor(ServerLevel level, ForceField f, Vec3 dir, long now) {
        long expire = now + f.doorTicks;
        double half = f.doorSize / 2.0 * 0.75;
        for (FieldDoor dr : f.doors) {
            if (dr.expireTick > now && DoorMath.inside(dr.dx, dr.dy, dr.dz, dir.x * f.radius, dir.y * f.radius, dir.z * f.radius, half)) {
                if (expire - dr.expireTick >= 10L) {
                    dr.expireTick = expire;
                    markDirty(f.dimension);
                }
                return;
            }
        }
        if (f.doors.size() >= 8) {
            f.doors.remove(0);
        }
        f.doors.add(new FieldDoor(dir.x, dir.y, dir.z, now, expire));
        markDirty(f.dimension);
        Vec3 at = f.center().add(dir.scale(f.radius));
        level.playSound(null, at.x, at.y, at.z, ModSounds.DOOR_OPEN.get(), SoundSource.PLAYERS, 1.2f, 1.0f);
    }

    // ------------------------------------------------------------------ dano / resistencia

    /** Resta resistencia al campo y avisa a los clientes (ondulacion + sonido). */
    public static void absorb(ServerLevel level, DedData d, ForceField f, float amount, Vec3 point) {
        float cost = amount * d.settings.damageMultiplier;
        f.resistance -= cost;
        boolean broken = f.resistance <= 0.0f;
        broadcastHit(level, f, point.subtract(f.center()), broken, Math.min(1.0f, Math.max(0.15f, cost / 30.0f)));
        markDirty(f.dimension);
        d.setDirty();
    }

    private static void broadcastHit(ServerLevel level, ForceField f, Vec3 dir, boolean broken, float strength) {
        Vec3 n = dir.lengthSqr() > 1.0E-6 ? dir.normalize() : new Vec3(0.0, 1.0, 0.0);
        ModNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension),
                new HitPacket(f.id, (float) n.x, (float) n.y, (float) n.z, broken, strength));
    }

    // ------------------------------------------------------------------ sincronizacion

    private static void flushSync(MinecraftServer server, DedData d) {
        boolean periodic = (++syncCounter % 100) == 0;
        if (DIRTY.isEmpty() && !periodic) {
            return;
        }
        Set<ResourceLocation> dims = new HashSet<>(DIRTY);
        if (periodic) {
            for (ForceField f : d.fields.values()) {
                dims.add(f.dimension);
            }
        }
        DIRTY.clear();
        for (ResourceLocation dim : dims) {
            ServerLevel lv = server.getLevel(dimKey(dim));
            if (lv == null) {
                continue;
            }
            ModNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(lv::dimension), FieldSyncPacket.from(lv, fieldsIn(d, dim)));
        }
    }

    public static void syncTo(ServerPlayer p) {
        DedData d = DedData.get(p.server);
        ServerLevel lv = p.serverLevel();
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                FieldSyncPacket.from(lv, fieldsIn(d, lv.dimension().location())));
    }

    // ------------------------------------------------------------------ eventos de dano

    /**
     * @return true si el ataque debe cancelarse (la victima esta dentro de un campo y el origen fuera).
     */
    public static boolean shouldBlockAttack(ServerLevel level, LivingEntity victim, net.minecraft.world.damagesource.DamageSource src, float amount) {
        Entity attacker = src.getEntity();
        Entity direct = src.getDirectEntity();
        Vec3 origin = attacker != null ? attacker.position() : direct != null ? direct.position() : src.getSourcePosition();
        if (origin == null) {
            return false;
        }
        DedData d = DedData.get(level.getServer());
        if (!d.settings.ffEnabled || d.fields.isEmpty()) {
            return false;
        }
        Vec3 body = victim.position().add(0.0, victim.getBbHeight() / 2.0, 0.0);
        for (ForceField f : fieldsIn(d, level.dimension().location())) {
            if (!f.blockAttacks || f.resistance <= 0.0f) {
                continue;
            }
            if (f.contains(body) && !f.contains(origin)) {
                Vec3 c = f.center();
                Vec3 dir = origin.subtract(c);
                Vec3 point = dir.lengthSqr() > 1.0E-6 ? c.add(dir.normalize().scale(f.radius)) : c;
                absorb(level, d, f, amount, point);
                return true;
            }
        }
        return false;
    }

    /** Filtra una explosion: quita bloques y entidades que estan dentro de un campo si la explosion nace fuera. */
    public static void filterExplosion(ServerLevel level, Vec3 origin, List<net.minecraft.core.BlockPos> blocks, List<Entity> entities) {
        DedData d = DedData.get(level.getServer());
        if (!d.settings.ffEnabled || d.fields.isEmpty()) {
            return;
        }
        for (ForceField f : fieldsIn(d, level.dimension().location())) {
            if (!f.blockExplosions || f.resistance <= 0.0f || f.contains(origin)) {
                continue;
            }
            boolean hit = blocks.removeIf(pos -> f.contains(Vec3.atCenterOf(pos)));
            hit |= entities.removeIf(en -> f.contains(en.position().add(0.0, en.getBbHeight() / 2.0, 0.0)));
            if (hit) {
                Vec3 c = f.center();
                Vec3 dir = origin.subtract(c);
                Vec3 point = dir.lengthSqr() > 1.0E-6 ? c.add(dir.normalize().scale(f.radius)) : c;
                absorb(level, d, f, d.settings.explosionCost, point);
            }
        }
    }

    public static boolean isPlayerInsideAny(DedData d, Player p) {
        Vec3 body = p.position().add(0.0, p.getBbHeight() / 2.0, 0.0);
        for (ForceField f : d.fields.values()) {
            if (f.dimension.equals(p.level().dimension().location()) && f.contains(body)) {
                return true;
            }
        }
        return false;
    }
}
