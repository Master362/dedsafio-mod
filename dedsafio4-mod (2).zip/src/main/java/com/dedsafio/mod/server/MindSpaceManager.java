package com.dedsafio.mod.server;

import com.dedsafio.mod.DedsafioMod;
import com.dedsafio.mod.data.DedData;
import com.dedsafio.mod.data.Mechanic;
import com.dedsafio.mod.data.ModSettings;
import com.dedsafio.mod.net.ModNetwork;
import com.dedsafio.mod.net.WarpPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Espacio mental de Eon: viaje dimensional (transicion de vacio negro con destellos en el cliente)
 * y teletransporte real a una dimension astral oscura (dedsafio4:mind_space) al terminar.
 */
public final class MindSpaceManager {
    public static final ResourceKey<Level> MIND_SPACE =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(DedsafioMod.MODID, "mind_space"));

    private static final class Warp {
        int age = 0;
        int total;
        int teleportAt;
    }

    private static final Map<UUID, Warp> WARPS = new HashMap<>();
    private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
    private static long serverTicks = 0L;

    private MindSpaceManager() {}

    public static boolean isWarping(ServerPlayer p) {
        return WARPS.containsKey(p.getUUID());
    }

    public static void clearStatics() {
        WARPS.clear();
        COOLDOWNS.clear();
        serverTicks = 0L;
    }

    public static void forget(UUID id) {
        WARPS.remove(id);
    }

    /** Uso del item "Orbe astral de Eon". */
    public static void useItem(ServerPlayer p) {
        ModSettings s = DedData.get(p.server).settings;
        if (!s.voEnabled) {
            p.displayClientMessage(Component.translatable("msg.dedsafio4.mechanic_disabled"), true);
            return;
        }
        if (!Perms.can(p, Mechanic.VOID)) {
            p.displayClientMessage(Component.translatable("msg.dedsafio4.no_permission"), true);
            return;
        }
        start(p, true);
    }

    /**
     * Inicia el viaje. Si el jugador esta en el Espacio mental vuelve; si no, va hacia alli.
     * @return true si el viaje empezo.
     */
    public static boolean start(ServerPlayer p, boolean checkCooldown) {
        MinecraftServer server = p.server;
        ModSettings s = DedData.get(server).settings;
        if (WARPS.containsKey(p.getUUID())) {
            return false;
        }
        if (server.getLevel(MIND_SPACE) == null) {
            p.displayClientMessage(Component.translatable("msg.dedsafio4.no_dimension"), false);
            return false;
        }
        if (checkCooldown) {
            Long until = COOLDOWNS.get(p.getUUID());
            if (until != null && until > serverTicks) {
                long left = (until - serverTicks + 19L) / 20L;
                p.displayClientMessage(Component.translatable("msg.dedsafio4.cooldown", left), true);
                return false;
            }
        }
        Warp w = new Warp();
        w.total = Math.max(10, s.voDurationTicks);
        w.teleportAt = Math.round(w.total * 0.6f);
        WARPS.put(p.getUUID(), w);
        COOLDOWNS.put(p.getUUID(), serverTicks + (long) s.voCooldownSec * 20L + w.total);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new WarpPacket(w.total, s.voIntensity, s.voColor));
        return true;
    }

    public static void tick(MinecraftServer server) {
        serverTicks++;
        if (WARPS.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<UUID, Warp>> it = WARPS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Warp> en = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
            Warp w = en.getValue();
            if (p == null) {
                it.remove();
                continue;
            }
            w.age++;
            if (w.age < w.teleportAt) {
                // durante el viaje el jugador queda inmovil
                p.setDeltaMovement(Vec3.ZERO);
                p.hurtMarked = true;
                p.fallDistance = 0.0f;
            }
            if (w.age == w.teleportAt) {
                doTeleport(server, p);
            }
            if (w.age >= w.total) {
                it.remove();
            }
        }
    }

    private static void doTeleport(MinecraftServer server, ServerPlayer p) {
        DedData d = DedData.get(server);
        ModSettings s = d.settings;
        if (p.level().dimension().equals(MIND_SPACE)) {
            DedData.ReturnPoint rp = d.returns.remove(p.getUUID());
            ServerLevel target;
            double x, y, z;
            float yRot = p.getYRot(), xRot = p.getXRot();
            if (rp != null && server.getLevel(ForceFieldManager.dimKey(new ResourceLocation(rp.dim))) != null) {
                target = server.getLevel(ForceFieldManager.dimKey(new ResourceLocation(rp.dim)));
                x = rp.x; y = rp.y; z = rp.z; yRot = rp.yRot; xRot = rp.xRot;
            } else {
                target = server.overworld();
                BlockPos spawn = target.getSharedSpawnPos();
                x = spawn.getX() + 0.5; y = spawn.getY() + 1.0; z = spawn.getZ() + 0.5;
            }
            d.setDirty();
            p.teleportTo(target, x, y, z, yRot, xRot);
        } else {
            ServerLevel mind = server.getLevel(MIND_SPACE);
            if (mind == null) {
                return;
            }
            if (!d.mindBuilt || d.mindBuiltY != s.voPlatformY) {
                buildPlatform(mind, s.voPlatformY);
                d.mindBuilt = true;
                d.mindBuiltY = s.voPlatformY;
            }
            d.returns.put(p.getUUID(), new DedData.ReturnPoint(p.level().dimension().location().toString(),
                    p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot()));
            d.setDirty();
            p.teleportTo(mind, 0.5, s.voPlatformY + 1.0, 0.5, p.getYRot(), 0.0f);
        }
    }

    /** Reconstruye la plataforma astral (comando /dedsafio void rebuild). */
    public static boolean rebuild(MinecraftServer server) {
        ServerLevel mind = server.getLevel(MIND_SPACE);
        if (mind == null) {
            return false;
        }
        DedData d = DedData.get(server);
        buildPlatform(mind, d.settings.voPlatformY);
        d.mindBuilt = true;
        d.mindBuiltY = d.settings.voPlatformY;
        d.setDirty();
        return true;
    }

    private static void put(ServerLevel lvl, BlockPos pos, BlockState st) {
        lvl.setBlock(pos, st, 2);
    }

    private static BlockState topBlock(double dist, int radius, RandomSource rnd) {
        float r = rnd.nextFloat();
        if (dist > radius - 1.5) {
            return r < 0.7f ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.OBSIDIAN.defaultBlockState();
        }
        if (r < 0.50f) return Blocks.OBSIDIAN.defaultBlockState();
        if (r < 0.82f) return Blocks.POLISHED_BLACKSTONE.defaultBlockState();
        if (r < 0.91f) return Blocks.CRYING_OBSIDIAN.defaultBlockState();
        return Blocks.AMETHYST_BLOCK.defaultBlockState();
    }

    /** Isla astral oscura: disco de obsidiana/blackstone, cristales, obelisco y pequenas islas flotantes. */
    static void buildPlatform(ServerLevel lvl, int y) {
        RandomSource rnd = RandomSource.create(4242L);
        final int radius = 14;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radius) {
                    continue;
                }
                int depth = 1 + (int) ((1.0 - dist / radius) * 4.0);
                for (int k = 0; k < depth; k++) {
                    BlockState st = k == 0 ? topBlock(dist, radius, rnd)
                            : (rnd.nextFloat() < 0.12f ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.OBSIDIAN.defaultBlockState());
                    put(lvl, new BlockPos(dx, y - k, dz), st);
                }
                // aire libre encima del disco (por si habia algo de una reconstruccion anterior)
                for (int k = 1; k <= 6; k++) {
                    put(lvl, new BlockPos(dx, y + k, dz), Blocks.AIR.defaultBlockState());
                }
            }
        }
        // varillas de luz en un anillo
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0;
            BlockPos p = new BlockPos((int) Math.round(Math.cos(a) * 11), y + 1, (int) Math.round(Math.sin(a) * 11));
            put(lvl, p, Blocks.END_ROD.defaultBlockState());
        }
        // cristales de amatista aleatorios
        for (int i = 0; i < 14; i++) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            double r = 3.0 + rnd.nextDouble() * 9.0;
            BlockPos p = new BlockPos((int) Math.round(Math.cos(a) * r), y + 1, (int) Math.round(Math.sin(a) * r));
            put(lvl, p, Blocks.AMETHYST_CLUSTER.defaultBlockState());
        }
        // obelisco
        for (int k = 1; k <= 5; k++) {
            put(lvl, new BlockPos(0, y + k, -7), Blocks.CRYING_OBSIDIAN.defaultBlockState());
        }
        put(lvl, new BlockPos(0, y + 6, -7), Blocks.END_ROD.defaultBlockState());
        // islas flotantes
        for (int i = 0; i < 7; i++) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            double dist = 22.0 + rnd.nextDouble() * 16.0;
            int cx = (int) Math.round(Math.cos(a) * dist);
            int cz = (int) Math.round(Math.sin(a) * dist);
            int cy = y + rnd.nextInt(18) - 8;
            int rr = 3 + rnd.nextInt(3);
            for (int dx = -rr; dx <= rr; dx++) {
                for (int dy = -rr; dy <= 1; dy++) {
                    for (int dz = -rr; dz <= rr; dz++) {
                        double e = (dx * dx + dz * dz) / (double) (rr * rr) + (dy * dy) / (double) (rr * rr) * 1.6;
                        if (e <= 1.0 && cy + dy > 1) {
                            BlockState st = rnd.nextFloat() < 0.15f ? Blocks.AMETHYST_BLOCK.defaultBlockState()
                                    : (rnd.nextBoolean() ? Blocks.OBSIDIAN.defaultBlockState() : Blocks.POLISHED_BLACKSTONE.defaultBlockState());
                            put(lvl, new BlockPos(cx + dx, cy + dy, cz + dz), st);
                        }
                    }
                }
            }
            put(lvl, new BlockPos(cx, cy + 2, cz), Blocks.AMETHYST_CLUSTER.defaultBlockState());
        }
    }
}
