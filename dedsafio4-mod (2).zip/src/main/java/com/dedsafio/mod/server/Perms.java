package com.dedsafio.mod.server;

import com.dedsafio.mod.data.DedData;
import com.dedsafio.mod.data.Mechanic;
import com.dedsafio.mod.data.ModSettings;
import net.minecraft.server.level.ServerPlayer;

/** Permisos por mecanica: nivel minimo de operador + lista de jugadores permitidos individualmente. */
public final class Perms {
    private Perms() {}

    public static boolean can(ServerPlayer player, Mechanic mechanic) {
        ModSettings s = DedData.get(player.server).settings;
        int level = s.permLevel.getOrDefault(mechanic, 2);
        return player.hasPermissions(level) || s.allowed.get(mechanic).contains(player.getUUID());
    }
}
