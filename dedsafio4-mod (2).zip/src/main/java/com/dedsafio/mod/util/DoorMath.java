package com.dedsafio.mod.util;

/**
 * Matematica de la "puertita" cuadrada del campo de fuerza.
 * Se usa EXACTAMENTE igual en el servidor (fisica) y en el cliente (recorte visual),
 * asi lo que se ve abierto es lo que se puede atravesar.
 *
 * La puerta es un cuadrado de lado 2*half, centrado en la direccion unitaria c (desde el centro de la esfera),
 * con ejes t1 (horizontal) y t2 (vertical aproximado).
 */
public final class DoorMath {
    /** Ticks que dura la animacion de apertura/cierre. */
    public static final int ANIM_TICKS = 6;

    private DoorMath() {}

    /** Eje horizontal de la puerta: normalize(up x c). */
    public static double[] tangent1(double cx, double cy, double cz) {
        double x = cz, z = -cx;
        double l = Math.sqrt(x * x + z * z);
        if (l < 1.0E-5) {
            return new double[] {1.0, 0.0, 0.0};
        }
        return new double[] {x / l, 0.0, z / l};
    }

    /** Eje vertical de la puerta: c x t1. */
    public static double[] tangent2(double cx, double cy, double cz, double[] t1) {
        return new double[] {
                cy * t1[2] - cz * t1[1],
                cz * t1[0] - cx * t1[2],
                cx * t1[1] - cy * t1[0]
        };
    }

    /** true si el punto relativo al centro (px,py,pz) esta dentro del cuadrado de la puerta. */
    public static boolean inside(double cx, double cy, double cz, double px, double py, double pz, double half) {
        if (half <= 0.0) {
            return false;
        }
        double f = px * cx + py * cy + pz * cz;
        if (f <= 0.0) {
            return false;
        }
        double[] t1 = tangent1(cx, cy, cz);
        double[] t2 = tangent2(cx, cy, cz, t1);
        double a = px * t1[0] + py * t1[1] + pz * t1[2];
        double b = px * t2[0] + py * t2[1] + pz * t2[2];
        return Math.abs(a) <= half && Math.abs(b) <= half;
    }

    /** Progreso de apertura 0..1 (suavizado) segun los ticks de apertura y expiracion. */
    public static float progress(long openTick, long expireTick, float now) {
        float in = Math.min(1.0f, (now - openTick) / ANIM_TICKS);
        float out = Math.min(1.0f, (expireTick - now) / ANIM_TICKS);
        float p = Math.max(0.0f, Math.min(in, out));
        return p * p * (3.0f - 2.0f * p);
    }
}
