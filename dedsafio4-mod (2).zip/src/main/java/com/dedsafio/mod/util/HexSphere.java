package com.dedsafio.mod.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Esfera geodesica hexagonal (dual de un icosaedro subdividido): 12 pentagonos + hexagonos,
 * igual que la cupula de la imagen de referencia. Sin dependencias de Minecraft.
 *
 * subdivisiones 2 -> 162 celdas, 3 -> 642 celdas.
 */
public final class HexSphere {
    private static final HexSphere[] CACHE = new HexSphere[5];

    public final int cellCount;
    /** Centro (vector unitario) de cada celda. */
    public final double[][] centers;
    /** Vertices (vectores unitarios) del poligono de cada celda, ordenados. */
    public final double[][][] polys;
    /** Aristas unicas entre celdas: [n][2][3]. */
    public final double[][][] edges;
    /** Valor pseudoaleatorio 0..1 fijo por celda. */
    public final float[] rnd;

    public static synchronized HexSphere get(int subdivisions) {
        int s = Math.max(0, Math.min(4, subdivisions));
        if (CACHE[s] == null) {
            CACHE[s] = new HexSphere(s);
        }
        return CACHE[s];
    }

    private HexSphere(int subdiv) {
        List<double[]> verts = new ArrayList<>();
        double t = (1.0 + Math.sqrt(5.0)) / 2.0;
        double[][] base = {
                {-1, t, 0}, {1, t, 0}, {-1, -t, 0}, {1, -t, 0},
                {0, -1, t}, {0, 1, t}, {0, -1, -t}, {0, 1, -t},
                {t, 0, -1}, {t, 0, 1}, {-t, 0, -1}, {-t, 0, 1}
        };
        for (double[] b : base) {
            verts.add(normalize(b));
        }
        int[][] f0 = {
                {0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11},
                {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
                {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9},
                {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}
        };
        List<int[]> faces = new ArrayList<>(Arrays.asList(f0));
        for (int i = 0; i < subdiv; i++) {
            Map<Long, Integer> cache = new HashMap<>();
            List<int[]> next = new ArrayList<>();
            for (int[] f : faces) {
                int ab = mid(verts, cache, f[0], f[1]);
                int bc = mid(verts, cache, f[1], f[2]);
                int ca = mid(verts, cache, f[2], f[0]);
                next.add(new int[] {f[0], ab, ca});
                next.add(new int[] {f[1], bc, ab});
                next.add(new int[] {f[2], ca, bc});
                next.add(new int[] {ab, bc, ca});
            }
            faces = next;
        }

        // centroides de cada cara = vertices de las celdas duales
        double[][] fc = new double[faces.size()][];
        List<List<Integer>> vertFaces = new ArrayList<>();
        for (int i = 0; i < verts.size(); i++) {
            vertFaces.add(new ArrayList<>());
        }
        Map<Long, List<Integer>> edgeFaces = new HashMap<>();
        for (int i = 0; i < faces.size(); i++) {
            int[] f = faces.get(i);
            double[] a = verts.get(f[0]), b = verts.get(f[1]), c = verts.get(f[2]);
            fc[i] = normalize(new double[] {a[0] + b[0] + c[0], a[1] + b[1] + c[1], a[2] + b[2] + c[2]});
            for (int k = 0; k < 3; k++) {
                vertFaces.get(f[k]).add(i);
                edgeFaces.computeIfAbsent(key(f[k], f[(k + 1) % 3]), q -> new ArrayList<>()).add(i);
            }
        }

        this.cellCount = verts.size();
        this.centers = new double[cellCount][];
        this.polys = new double[cellCount][][];
        this.rnd = new float[cellCount];
        Random rng = new Random(20240604L);
        for (int v = 0; v < cellCount; v++) {
            double[] n = verts.get(v);
            centers[v] = n;
            double[] ref = Math.abs(n[1]) < 0.9 ? new double[] {0, 1, 0} : new double[] {1, 0, 0};
            double[] t1 = normalize(cross(n, ref));
            double[] t2 = cross(n, t1);
            List<Integer> fl = new ArrayList<>(vertFaces.get(v));
            final double[] ft1 = t1, ft2 = t2;
            fl.sort((p, q) -> Double.compare(angle(fc[p], ft1, ft2), angle(fc[q], ft1, ft2)));
            double[][] poly = new double[fl.size()][];
            for (int k = 0; k < poly.length; k++) {
                poly[k] = fc[fl.get(k)];
            }
            polys[v] = poly;
            rnd[v] = rng.nextFloat();
        }

        List<double[][]> el = new ArrayList<>();
        for (List<Integer> fl : edgeFaces.values()) {
            if (fl.size() == 2) {
                el.add(new double[][] {fc[fl.get(0)], fc[fl.get(1)]});
            }
        }
        this.edges = el.toArray(new double[0][][]);
    }

    private static double angle(double[] p, double[] t1, double[] t2) {
        return Math.atan2(p[0] * t2[0] + p[1] * t2[1] + p[2] * t2[2], p[0] * t1[0] + p[1] * t1[1] + p[2] * t1[2]);
    }

    private static long key(int a, int b) {
        return ((long) Math.min(a, b) << 32) | (long) Math.max(a, b);
    }

    private static int mid(List<double[]> verts, Map<Long, Integer> cache, int a, int b) {
        long k = key(a, b);
        Integer found = cache.get(k);
        if (found != null) {
            return found;
        }
        double[] p = verts.get(a), q = verts.get(b);
        verts.add(normalize(new double[] {p[0] + q[0], p[1] + q[1], p[2] + q[2]}));
        int idx = verts.size() - 1;
        cache.put(k, idx);
        return idx;
    }

    private static double[] normalize(double[] v) {
        double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return new double[] {v[0] / l, v[1] / l, v[2] / l};
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[] {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }
}
