package com.dedsafio.mod.util;

import java.util.ArrayList;
import java.util.List;

/** Recorte de poligonos convexos (Sutherland-Hodgman) con color por vertice. Sin dependencias de Minecraft. */
public final class PolyClip {
    private PolyClip() {}

    public static final class Vx {
        public double x, y, z;
        public float r, g, b, a;

        public Vx(double x, double y, double z, float r, float g, float b, float a) {
            this.x = x; this.y = y; this.z = z;
            this.r = r; this.g = g; this.b = b; this.a = a;
        }

        static Vx lerp(Vx p, Vx q, double t) {
            float tf = (float) t;
            return new Vx(
                    p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, p.z + (q.z - p.z) * t,
                    p.r + (q.r - p.r) * tf, p.g + (q.g - p.g) * tf, p.b + (q.b - p.b) * tf, p.a + (q.a - p.a) * tf);
        }
    }

    /** Conserva la parte donde (n.p - d) >= 0 (keepGE) o <= 0 (!keepGE). */
    public static List<Vx> clip(List<Vx> poly, double[] n, double d, boolean keepGE) {
        List<Vx> out = new ArrayList<>(poly.size() + 2);
        int cnt = poly.size();
        if (cnt == 0) {
            return out;
        }
        double sgn = keepGE ? 1.0 : -1.0;
        for (int i = 0; i < cnt; i++) {
            Vx a = poly.get(i);
            Vx b = poly.get((i + 1) % cnt);
            double da = (n[0] * a.x + n[1] * a.y + n[2] * a.z - d) * sgn;
            double db = (n[0] * b.x + n[1] * b.y + n[2] * b.z - d) * sgn;
            boolean ia = da >= 0.0;
            boolean ib = db >= 0.0;
            if (ia) {
                out.add(a);
            }
            if (ia != ib) {
                out.add(Vx.lerp(a, b, da / (da - db)));
            }
        }
        return out;
    }

    private static void addIfValid(List<List<Vx>> res, List<Vx> p) {
        if (p.size() >= 3) {
            res.add(p);
        }
    }

    /**
     * Resta del poligono el cuadrado de la puerta (|a|<h, |b|<h, f>0) y devuelve las piezas convexas restantes.
     * c = direccion de la puerta, t1/t2 = ejes. Todo relativo al centro de la esfera.
     */
    public static void subtractDoor(List<Vx> poly, double[] c, double[] t1, double[] t2, double h, List<List<Vx>> out) {
        // Descarte rapido: totalmente fuera del cuadrado
        boolean allBack = true, allALow = true, allAHigh = true, allBLow = true, allBHigh = true;
        for (Vx v : poly) {
            double f = v.x * c[0] + v.y * c[1] + v.z * c[2];
            double a = v.x * t1[0] + v.y * t1[1] + v.z * t1[2];
            double b = v.x * t2[0] + v.y * t2[1] + v.z * t2[2];
            if (f > 0.0) allBack = false;
            if (a > -h) allALow = false;
            if (a < h) allAHigh = false;
            if (b > -h) allBLow = false;
            if (b < h) allBHigh = false;
        }
        if (allBack || allALow || allAHigh || allBLow || allBHigh) {
            out.add(poly);
            return;
        }
        addIfValid(out, clip(poly, c, 0.0, false));              // detras del plano de la puerta
        List<Vx> front = clip(poly, c, 0.0, true);
        if (front.size() < 3) {
            return;
        }
        addIfValid(out, clip(front, t1, -h, false));             // a < -h
        List<Vx> mid = clip(front, t1, -h, true);
        addIfValid(out, clip(mid, t1, h, true));                 // a > h
        mid = clip(mid, t1, h, false);                           // -h <= a <= h
        addIfValid(out, clip(mid, t2, -h, false));               // b < -h
        addIfValid(out, clip(mid, t2, h, true));                 // b > h
    }
}
