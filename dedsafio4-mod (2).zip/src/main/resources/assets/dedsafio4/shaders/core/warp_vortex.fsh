#version 150

in vec2 texCoord0;

uniform vec4 ColorModulator;
uniform float Time;    // tiempo acumulado (ya incluye la velocidad)
uniform float Fade;    // opacidad global del vacio negro 0..1
uniform float Aspect;  // ancho / alto de la pantalla
uniform vec3 Tint;     // color de los destellos

out vec4 fragColor;

float hash11(float n) {
    return fract(sin(n * 91.3458) * 47453.5453);
}

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

// Una capa de destellos: rayos finos que nacen en el centro y se estiran hacia los bordes
float streakLayer(vec2 p, float count, float seed, float speed, float lenScale) {
    float r = length(p);
    float a = atan(p.y, p.x) / 6.2831853 + 0.5;
    float id = floor(a * count);
    float local = fract(a * count) - 0.5;

    float h1 = hash11(id + seed);
    float h2 = hash11(id * 1.37 + seed * 3.1);
    float on = step(0.42, h2);

    float phase = fract(h1 + Time * speed * (0.35 + 0.9 * h1));
    float head = phase * phase * 2.4;
    float len = (0.05 + 0.55 * head) * lenScale;
    float along = (r - (head - len)) / len;
    float inside = step(0.0, along) * step(along, 1.0);

    float perp = abs(local) * (6.2831853 * max(r, 0.001) / count);
    float width = (0.0012 + 0.022 * head) * along;
    float core = smoothstep(width, width * 0.15, perp);

    return on * inside * core * along;
}

void main() {
    vec2 p = (texCoord0 - 0.5) * vec2(Aspect, 1.0) * 2.0;
    float r = length(p);

    float s = 0.0;
    s += streakLayer(p, 48.0, 1.0, 0.55, 1.0);
    s += streakLayer(p, 80.0, 7.0, 0.80, 0.7);
    s += streakLayer(p, 130.0, 13.0, 1.10, 0.5);
    s += streakLayer(p, 30.0, 21.0, 0.35, 1.4);
    s = clamp(s, 0.0, 1.0);

    // centro oscuro con motas diminutas, como en la referencia
    float centerMask = smoothstep(0.04, 0.35, r);
    float specks = step(0.985, hash21(floor(p * 60.0 + Time * 3.0))) * (1.0 - centerMask) * 0.6;
    float v = clamp(s * centerMask + specks, 0.0, 1.0);

    vec3 col = Tint * v;
    fragColor = vec4(col, clamp(Fade, 0.0, 1.0)) * ColorModulator;
}
