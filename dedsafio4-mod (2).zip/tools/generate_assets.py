#!/usr/bin/env python3
"""Genera TODAS las texturas y sonidos del mod (estilo hexagonal violeta / vacio negro de Eon).
Uso:  python3 tools/generate_assets.py   (requiere pillow, numpy, scipy, ffmpeg con libvorbis)
Los resultados ya vienen incluidos en src/main/resources; este script es solo para regenerarlos."""
import math, os, subprocess, tempfile
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "dedsafio4")
def path(*p):
    full = os.path.join(ROOT, *p)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    return full

# ---------------------------------------------------------------- helpers
def hexgrid(px, py, scale):
    """Distancia hexagonal (0.5 = borde de celda). Basado en la rejilla clasica de hexagonos."""
    x = px / scale; y = py / scale
    rx, ry = 1.0, 1.7320508
    hx, hy = rx * 0.5, ry * 0.5
    ax = np.mod(x, rx) - hx;        ay = np.mod(y, ry) - hy
    bx = np.mod(x - hx, rx) - hx;   by = np.mod(y - hy, ry) - hy
    use_a = (ax * ax + ay * ay) < (bx * bx + by * by)
    gx = np.where(use_a, ax, bx); gy = np.where(use_a, ay, by)
    gx = np.abs(gx); gy = np.abs(gy)
    c = np.maximum(gx * 0.5 + gy * 0.8660254, gx)
    return c

def save(img, *p):
    img.save(path(*p))

# ---------------------------------------------------------------- items
def revil_core():
    n = 16
    ys, xs = np.mgrid[0:n, 0:n].astype(float)
    cx = cy = 7.5
    dx = xs - cx; dy = ys - cy
    d = np.sqrt(dx * dx + dy * dy)
    img = np.zeros((n, n, 4), dtype=float)
    inside = d <= 6.6
    # shading: light from top-left
    nz = np.sqrt(np.clip(1 - (d / 6.6) ** 2, 0, 1))
    light = np.clip((-dx * 0.4 - dy * 0.5) / 6.6 + nz * 0.7, 0, 1.2)
    base_a = np.array([88, 28, 150]); base_b = np.array([235, 60, 140])
    t = np.clip((dx + dy) / 14 + 0.5, 0, 1)[..., None]
    col = base_a * (1 - t) + base_b * t
    col = col * (0.45 + light[..., None] * 0.75)
    e = hexgrid(xs, ys, 2.9)
    edge = np.clip((e - 0.40) / 0.10, 0, 1)
    col = col * (1 - edge[..., None] * 0.85) + np.array([235, 215, 255]) * edge[..., None] * 0.85
    img[..., :3] = np.clip(col, 0, 255)
    img[..., 3] = np.where(inside, 255, 0)
    rim = (d > 5.7) & (d <= 6.6)
    img[rim, :3] = img[rim, :3] * 0.6 + np.array([210, 160, 255]) * 0.4
    save(Image.fromarray(img.astype(np.uint8), "RGBA"), "textures", "item", "revil_core.png")

def eon_orb():
    n = 16
    ys, xs = np.mgrid[0:n, 0:n].astype(float)
    dx = xs - 7.5; dy = ys - 7.5
    d = np.sqrt(dx * dx + dy * dy)
    ang = np.arctan2(dy, dx)
    img = np.zeros((n, n, 4), dtype=float)
    inside = d <= 6.8
    img[..., :3] = 6
    # radial white streaks que salen del centro
    streak = np.zeros_like(d)
    for k, a0 in enumerate(np.linspace(0, 2 * math.pi, 9)[:-1] + 0.3):
        da = np.abs(((ang - a0 + math.pi) % (2 * math.pi)) - math.pi)
        width = 0.06 + d * 0.035
        s = np.clip(1 - da / width, 0, 1) * np.clip((d - 1.5) / 4.0, 0, 1)
        streak = np.maximum(streak, s * (0.7 + 0.3 * ((k * 37) % 3) / 2))
    img[..., :3] += streak[..., None] * 235
    rim = (d > 5.8) & (d <= 6.8)
    img[rim, :3] += np.array([70, 35, 120])
    img[..., 3] = np.where(inside, 255, 0)
    save(Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA"), "textures", "item", "eon_orb.png")

# ---------------------------------------------------------------- particulas
def sparks():
    for i in range(4):
        n = 16
        ys, xs = np.mgrid[0:n, 0:n].astype(float)
        dx = xs - 7.5; dy = ys - 7.5
        d = np.sqrt(dx * dx + dy * dy)
        r = 1.2 + i * 0.9  # tamano de brillo por frame
        glow = np.exp(-(d / (r + 1.3)) ** 2 * 1.6)
        cross = np.exp(-(np.minimum(np.abs(dx), np.abs(dy)) / 0.6) ** 2) * np.exp(-(d / (3.5 + i)) ** 2)
        a = np.clip(glow + cross * 0.8, 0, 1)
        img = np.zeros((n, n, 4))
        img[..., 0] = 225 + 30 * a; img[..., 1] = 200 + 55 * a; img[..., 2] = 255
        img[..., 3] = a * 255
        save(Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA"), "textures", "particle", f"spark_{i}.png")

# ---------------------------------------------------------------- GUI
def bubble():
    S = 8
    size = 48 * S
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    m = 2 * S
    dr.rounded_rectangle([m, m, size - m, size - m], radius=15 * S, fill=(120, 72, 196, 255))
    dr.rounded_rectangle([m + 2 * S, m + 2 * S, size - m - 2 * S, size - m - 2 * S], radius=13 * S, fill=(247, 243, 255, 255))
    # brillo suave arriba
    hl = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(hl).rounded_rectangle([m + 5 * S, m + 4 * S, size - m - 5 * S, size // 2 - 2 * S], radius=9 * S, fill=(255, 255, 255, 110))
    im = Image.alpha_composite(im, hl.filter(ImageFilter.GaussianBlur(2 * S)))
    save(im.resize((48, 48), Image.LANCZOS), "textures", "gui", "bubble.png")
    # cola de nube (dos circulos descendentes)
    S = 8; w = 24
    t = Image.new("RGBA", (w * S, w * S), (0, 0, 0, 0)); d = ImageDraw.Draw(t)
    for (cx, cy, r) in [(13, 6.5, 5.5), (7.5, 16.5, 3.4)]:
        d.ellipse([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], fill=(120, 72, 196, 255))
        r2 = r - 1.6
        d.ellipse([(cx - r2) * S, (cy - r2) * S, (cx + r2) * S, (cy + r2) * S], fill=(247, 243, 255, 255))
    save(t.resize((w, w), Image.LANCZOS), "textures", "gui", "bubble_tail.png")

def panel():
    W, H = 256, 256
    ys, xs = np.mgrid[0:H, 0:W].astype(float)
    t = ys / 214.0
    col = np.zeros((H, W, 4))
    col[..., 0] = 16 + 30 * t; col[..., 1] = 8 + 6 * t; col[..., 2] = 30 + 40 * t; col[..., 3] = 245
    e = hexgrid(xs, ys, 14.0)
    line = np.clip((e - 0.44) / 0.06, 0, 1)
    col[..., :3] = col[..., :3] * (1 - line[..., None] * 0.35) + np.array([190, 130, 255]) * line[..., None] * 0.35
    img = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8), "RGBA")
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, 229, 213], radius=8, fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0)); out.paste(img, (0, 0), mask)
    d = ImageDraw.Draw(out)
    d.rounded_rectangle([0, 0, 229, 213], radius=8, outline=(168, 96, 255, 255), width=2)
    d.rounded_rectangle([3, 3, 226, 210], radius=6, outline=(255, 90, 160, 120), width=1)
    save(out, "textures", "gui", "panel.png")

def hex_icon():
    S = 8; n = 16
    im = Image.new("RGBA", (n * S, n * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    pts = [(8 + 7 * math.cos(math.radians(60 * k + 30)), 8 + 7 * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    d.polygon([(x * S, y * S) for x, y in pts], fill=(90, 30, 150, 220), outline=(240, 220, 255, 255), width=S)
    pts2 = [(8 + 3.6 * math.cos(math.radians(60 * k + 30)), 8 + 3.6 * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    d.polygon([(x * S, y * S) for x, y in pts2], outline=(255, 120, 190, 255), width=S // 2)
    save(im.resize((n, n), Image.LANCZOS), "textures", "gui", "hex_icon.png")

# ---------------------------------------------------------------- sonidos
SR = 44100
def t_axis(sec): return np.linspace(0, sec, int(SR * sec), endpoint=False)
def env(t, a, d):  # ataque / caida exponencial
    return np.clip(t / max(a, 1e-4), 0, 1) * np.exp(-t / d)
def lowpass(x, k):
    out = np.zeros_like(x); acc = 0.0
    for i, v in enumerate(x):
        acc += (v - acc) * k; out[i] = acc
    return out
def norm(x, peak=0.85):
    return (x / (np.max(np.abs(x)) + 1e-9) * peak).astype(np.float32)
def write_ogg(name, x):
    from scipy.io import wavfile
    with tempfile.TemporaryDirectory() as td:
        w = os.path.join(td, "a.wav")
        wavfile.write(w, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", w, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4", path("sounds", name + ".ogg")], check=True)

def sounds():
    rng = np.random.default_rng(4)
    # activacion del campo: barrido ascendente + brillo hexagonal
    t = t_axis(1.5)
    f = 90 * (1 + 5.0 * (t / 1.5) ** 1.6)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * 0.6 + np.sin(ph * 2.01) * 0.25 + np.sin(ph * 3.02) * 0.12
    x += np.sin(2 * np.pi * 1318 * t) * 0.2 * np.clip((t - 0.9) / 0.1, 0, 1) * np.exp(-(t - 0.9).clip(0) / 0.35)
    x *= np.clip(t / 0.08, 0, 1) * np.exp(-np.clip(t - 1.0, 0, None) / 0.25)
    write_ogg("field_activate", norm(x))
    # golpe en el campo: chasquido electrico + anillo metalico
    t = t_axis(0.55)
    n = lowpass(rng.standard_normal(len(t)), 0.35) * env(t, 0.002, 0.05)
    z = np.sin(2 * np.pi * np.cumsum(1100 * np.exp(-t * 9) + 140) / SR) * env(t, 0.002, 0.12)
    ring = sum(np.sin(2 * np.pi * fr * t) * a for fr, a in [(523, .3), (787, .22), (1319, .14)]) * env(t, 0.003, 0.16)
    write_ogg("field_hit", norm(n * 0.7 + z * 0.7 + ring))
    # rotura del campo: cristal + estruendo
    t = t_axis(1.7)
    n = lowpass(rng.standard_normal(len(t)), 0.5) * env(t, 0.004, 0.35)
    gl = sum(np.sin(2 * np.pi * fr * t * (1 - 0.15 * t)) * a * env(t, 0.002, d) for fr, a, d in
             [(2100, .25, .5), (3100, .18, .35), (4300, .1, .25), (1500, .22, .6)])
    low = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 2.2) + 35) / SR) * env(t, 0.005, 0.5)
    write_ogg("field_break", norm(n * 0.6 + gl + low * 0.8))
    # apertura de la puerta cuadrada
    t = t_axis(0.5)
    a = np.sin(2 * np.pi * np.cumsum(520 + 700 * np.clip(t / 0.12, 0, 1)) / SR) * env(t, 0.004, 0.09)
    b = np.zeros_like(t); m = t > 0.1
    b[m] = np.sin(2 * np.pi * np.cumsum(780 + 900 * np.clip((t[m] - 0.1) / 0.12, 0, 1)) / SR) * env(t[m] - 0.1, 0.004, 0.12)
    shimmer = np.sin(2 * np.pi * 2637 * t) * env(t, 0.002, 0.05) * 0.2
    write_ogg("door_open", norm(a * 0.6 + b * 0.6 + shimmer))
    # viaje dimensional: 5s, subida -> estruendo en 3s -> cola
    T = 5.0; t = t_axis(T)
    p = t / T
    n = rng.standard_normal(len(t))
    nf = lowpass(n, 0.04) * 0.9 + lowpass(n, 0.3) * np.clip(p / 0.6, 0, 1) * 0.6
    f = 50 + 1500 * np.clip(p / 0.6, 0, 1) ** 2.2
    f = np.where(p > 0.6, 1550 * np.exp(-(p - 0.6) * 9) + 40, f)
    ph = 2 * np.pi * np.cumsum(f) / SR
    sw = np.sin(ph) * 0.5 + np.sin(ph * 1.5) * 0.25
    trem = 0.75 + 0.25 * np.sin(2 * np.pi * (4 + 22 * p) * t)
    amp = np.where(p < 0.6, 0.15 + 0.85 * (p / 0.6) ** 1.5, np.exp(-(p - 0.6) * 4.2))
    boom = np.sin(2 * np.pi * np.cumsum(90 * np.exp(-np.clip(t - 3.0, 0, None) * 3) + 28) / SR) * np.where(t > 3.0, np.exp(-(t - 3.0) / 0.9), 0) * 1.4
    x = (nf * 0.7 + sw * trem) * amp + boom
    x *= np.clip(t / 0.15, 0, 1) * np.clip((T - t) / 0.4, 0, 1)
    write_ogg("warp", norm(x))
    # burbuja de dialogo
    t = t_axis(0.16)
    x = np.sin(2 * np.pi * np.cumsum(620 + 700 * np.clip(t / 0.05, 0, 1)) / SR) * env(t, 0.003, 0.045)
    write_ogg("bubble", norm(x, 0.7))

if __name__ == "__main__":
    revil_core(); eon_orb(); sparks(); bubble(); panel(); hex_icon(); sounds()
    print("assets generados en", os.path.abspath(ROOT))
